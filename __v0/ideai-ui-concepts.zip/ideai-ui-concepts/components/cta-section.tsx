"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function CTASection() {
  return (
    <section className="py-32 px-6 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-accent/5 to-background" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(59,130,246,0.15),transparent_70%)]" />

      <div className="container mx-auto max-w-4xl relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          {/* Label */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-accent/50 bg-accent/5 text-accent text-sm font-mono mb-8">
            <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
            READY TO START
          </div>

          {/* Headline */}
          <h2 className="text-5xl md:text-7xl font-bold mb-8 text-balance leading-[1.1]">
            Your next great
            <br />
            <span className="text-accent">idea</span> starts here
          </h2>

          {/* Description */}
          <p className="text-xl md:text-2xl text-muted-foreground mb-12 text-balance leading-relaxed max-w-2xl mx-auto">
            {`Join thousands of creators, developers, and innovators building the future with Ideai.`}
          </p>

          {/* CTA */}
          <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 text-lg px-10 h-16 group">
            Get Started for Free
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>

          {/* Trust indicators */}
          <div className="mt-12 flex items-center justify-center gap-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-accent rounded-full" />
              No credit card required
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-accent rounded-full" />
              Start in seconds
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
