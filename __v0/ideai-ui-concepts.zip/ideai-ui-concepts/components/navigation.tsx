"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ThemeSwitcher } from "@/components/theme-switcher"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ChevronDown } from "lucide-react"

export function Navigation() {
  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 backdrop-blur-xl bg-background/80"
    >
      <div className="container mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <a href="/" className="font-mono text-2xl font-bold tracking-tight">
            <span className="text-foreground">Idea</span>
            <span className="text-accent">i</span>
          </a>
        </div>

        {/* Navigation links */}
        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Features
          </a>
          <a href="/spec-builder" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Spec Builder
          </a>
          <a href="/team" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Team Builder
          </a>
          <a href="/team/flow" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Interactive Flow
          </a>
          <a href="/directory" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Directory
          </a>
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors outline-none">
              Concept Pages
              <ChevronDown className="w-3 h-3" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem asChild>
                <a href="/concepts/gantt" className="cursor-pointer">
                  Project Timeline
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/concepts/dashboard" className="cursor-pointer">
                  Dashboard
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/concepts/playground" className="cursor-pointer">
                  AI Playground
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/concepts/templates" className="cursor-pointer">
                  SaaS Templates
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/concepts/timeline" className="cursor-pointer">
                  Timeline View
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/concepts/slides" className="cursor-pointer">
                  Feature Slides
                </a>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors outline-none">
              Data Viz
              <ChevronDown className="w-3 h-3" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem asChild>
                <a href="/libs/d3-graph" className="cursor-pointer">
                  D3.js Force Graph
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/libs/3d-graph" className="cursor-pointer">
                  3D Node Network
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/libs/table" className="cursor-pointer">
                  TanStack Table
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/libs/editor" className="cursor-pointer">
                  Tiptap Word Processor
                </a>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors outline-none">
              Libs
              <ChevronDown className="w-3 h-3" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem asChild>
                <a href="/libs/reveal" className="cursor-pointer">
                  Reveal.js Presentations
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/libs/charts" className="cursor-pointer">
                  Chart.js Analytics
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/libs/timeline-js" className="cursor-pointer">
                  TimelineJS History
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/libs/decision-tree" className="cursor-pointer">
                  Decision Tree Flow
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/libs/decision-cards" className="cursor-pointer">
                  Decision Cards
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <a href="/libs/dependency-viz" className="cursor-pointer">
                  Dependency Visualizer
                </a>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <a href="#how" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            How It Works
          </a>
          <a href="#examples" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
            Examples
          </a>
        </div>

        <div className="flex items-center gap-3">
          <ThemeSwitcher />
          <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
            Sign In
          </Button>
          <Button size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90">
            Get Started
          </Button>
        </div>
      </div>
    </motion.nav>
  )
}
