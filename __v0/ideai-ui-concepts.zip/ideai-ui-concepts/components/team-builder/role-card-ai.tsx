"use client"

import { motion } from "framer-motion"
import { Bot, DollarSign, Zap, TrendingUp } from "lucide-react"
import type { TeamMember } from "./types"

type Props = {
  member: TeamMember
  isHovered: boolean
  onHover: () => void
  onLeave: () => void
  onSelect: () => void
}

export function RoleCardAi({ member, isHovered, onHover, onLeave, onSelect }: Props) {
  return (
    <motion.button
      onClick={onSelect}
      onHoverStart={onHover}
      onHoverEnd={onLeave}
      className="relative group cursor-pointer text-left h-full"
    >
      <motion.div
        className="h-full p-8 rounded-2xl border-2 border-accent bg-card relative overflow-hidden transition-all duration-500"
        style={{
          transform: isHovered ? "scale(1.05)" : "scale(1)",
        }}
      >
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-accent/20 to-transparent"
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 1, 0] }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
        />

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-6">
            <motion.div
              className="w-12 h-12 rounded-full bg-accent/20 border-2 border-accent flex items-center justify-center"
              animate={{
                scale: [1, 1.1, 1],
              }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
            >
              <Bot className="w-6 h-6 text-accent" />
            </motion.div>
            <div>
              <h3 className="text-2xl font-bold text-foreground">{member.ai.name}</h3>
              <p className="text-sm text-accent font-mono">{member.ai.personality}</p>
            </div>
          </div>

          <p className="text-foreground/90 mb-6 text-sm leading-relaxed">{member.ai.description}</p>

          <div className="space-y-4 mb-6">
            <div className="flex items-center justify-between py-2 border-b border-accent/20">
              <span className="text-sm text-foreground/80 flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-accent" />
                Cost Per Use
              </span>
              <span className="font-mono font-bold text-accent">{member.ai.cost}</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-accent/20">
              <span className="text-sm text-foreground/80 flex items-center gap-2">
                <Zap className="w-4 h-4 text-accent" />
                Execution
              </span>
              <span className="font-mono text-accent">{member.ai.time}</span>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{
              opacity: isHovered ? 1 : 0,
              height: isHovered ? "auto" : 0,
            }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="pt-4 border-t border-accent/20">
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="w-4 h-4 text-accent" />
                <span className="text-xs font-mono text-accent uppercase">AI Advantages</span>
              </div>
              <ul className="space-y-2">
                {member.ai.pros.map((pro, i) => (
                  <li key={i} className="text-sm text-foreground/90 pl-6 flex items-start gap-2">
                    <span className="text-accent mt-0.5">✓</span>
                    <span>{pro}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>

          {!isHovered && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-xs text-accent/60 font-mono text-center pt-4"
            >
              Hover to see advantages
            </motion.p>
          )}
        </div>
      </motion.div>
    </motion.button>
  )
}
