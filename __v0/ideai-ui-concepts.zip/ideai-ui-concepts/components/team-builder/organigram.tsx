"use client"

import { motion } from "framer-motion"
import { Users, Bot, Sparkles } from "lucide-react"
import type { Selection } from "./types"

type Props = {
  selections: Selection[]
}

export function Organigram({ selections }: Props) {
  const getIcon = (type: "human" | "ai" | "hybrid") => {
    switch (type) {
      case "human":
        return Users
      case "ai":
        return Bot
      case "hybrid":
        return Sparkles
    }
  }

  const getColor = (type: "human" | "ai" | "hybrid") => {
    switch (type) {
      case "human":
        return { bg: "bg-muted/50", border: "border-border", text: "text-muted-foreground" }
      case "ai":
        return { bg: "bg-accent/10", border: "border-accent", text: "text-accent" }
      case "hybrid":
        return { bg: "bg-accent/20", border: "border-accent/50", text: "text-accent" }
    }
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
      <div className="text-center">
        <h3 className="text-3xl font-bold mb-2">Your Team Structure</h3>
        <p className="text-muted-foreground">Organizational chart of your selected team</p>
      </div>

      <div className="relative">
        {/* Flow lines connecting nodes */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 0 }}>
          <defs>
            <linearGradient id="lineGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="rgb(59, 130, 246)" stopOpacity="0.5" />
              <stop offset="100%" stopColor="rgb(59, 130, 246)" stopOpacity="0.1" />
            </linearGradient>
          </defs>
        </svg>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {selections.map((selection, idx) => {
            const Icon = getIcon(selection.type)
            const colors = getColor(selection.type)

            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.1 }}
                className={`p-6 rounded-xl border-2 ${colors.border} ${colors.bg} backdrop-blur-sm relative`}
              >
                <div className="flex flex-col items-center text-center space-y-3">
                  <div
                    className={`w-12 h-12 rounded-full ${colors.bg} border-2 ${colors.border} flex items-center justify-center`}
                  >
                    <Icon className={`w-6 h-6 ${colors.text}`} />
                  </div>
                  <div>
                    <h4 className={`font-bold text-sm ${colors.text}`}>{selection.role}</h4>
                    <p className="text-xs text-muted-foreground mt-1">{selection.time}</p>
                  </div>
                  <div className="text-xs font-mono font-bold">{selection.cost}</div>
                </div>

                {/* Connection indicator */}
                {idx < selections.length - 1 && (
                  <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-0.5 h-6 bg-accent/30" />
                )}
              </motion.div>
            )
          })}
        </div>
      </div>
    </motion.div>
  )
}
