"use client"

import { motion } from "framer-motion"
import { Check, Circle, DollarSign, Clock } from "lucide-react"
import type { Selection } from "./types"

interface ProgressSidebarProps {
  currentIndex: number
  selections: Selection[]
  teamMembers: {
    id: string
    human: { role: string; cost: string; time: string }
    ai: { cost: string; time: string }
    hybrid?: { cost: string; time: string }
  }[]
  onStepClick: (index: number) => void
}

export function ProgressSidebar({ currentIndex, selections, teamMembers, onStepClick }: ProgressSidebarProps) {
  const calculateTotals = () => {
    const humanSelections = selections.filter((s) => s.type === "human")
    const aiSelections = selections.filter((s) => s.type === "ai")
    const hybridSelections = selections.filter((s) => s.type === "hybrid")

    const humanCostTotal = humanSelections.reduce((sum, s) => {
      const costStr = s.cost.replace(/\$|k\/year|,/g, "")
      return sum + Number.parseInt(costStr) * 1000
    }, 0)

    const hybridCostTotal = hybridSelections.reduce((sum, s) => {
      const costStr = s.cost.replace(/\$|k\/year|,/g, "")
      return sum + Number.parseInt(costStr) * 1000
    }, 0)

    // AI costs are per-use, so showing as variable
    const totalAnnualCost = humanCostTotal + hybridCostTotal

    // Estimate project length based on selections
    const hasAnyHuman = humanSelections.length > 0 || hybridSelections.length > 0
    const projectWeeks = hasAnyHuman ? Math.max(12, humanSelections.length * 2) : 4

    return {
      humanCount: humanSelections.length,
      aiCount: aiSelections.length,
      hybridCount: hybridSelections.length,
      totalAnnualCost,
      projectWeeks,
    }
  }

  const totals = selections.length > 0 ? calculateTotals() : null

  return (
    <div className="w-80 border-r border-border bg-card/50 backdrop-blur-sm flex flex-col">
      <div className="p-6 border-b border-border">
        <div className="text-xs font-mono text-muted-foreground mb-1">TEAM BUILDER</div>
        <div className="text-sm text-muted-foreground">Select your team composition</div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {teamMembers.map((member, index) => {
          const selection = selections.find((s) => s.roleId === member.id)
          const isCompleted = !!selection
          const isCurrent = index === currentIndex
          const isClickable = isCompleted

          return (
            <motion.button
              key={member.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => isClickable && onStepClick(index)}
              disabled={!isClickable}
              className={`w-full text-left p-3 rounded-lg transition-all border ${
                isCurrent
                  ? "bg-accent/10 border-accent/50 shadow-lg shadow-accent/20"
                  : isCompleted
                    ? "hover:bg-accent/5 cursor-pointer border-border hover:border-accent/30 bg-card"
                    : "opacity-40 cursor-not-allowed border-border/50 bg-card/50"
              }`}
            >
              <div className="flex items-center gap-3">
                <div>
                  {isCompleted ? (
                    <div
                      className={`w-5 h-5 rounded-full flex items-center justify-center ${
                        selection.type === "human"
                          ? "bg-zinc-500"
                          : selection.type === "hybrid"
                            ? "bg-purple-500"
                            : "bg-accent"
                      }`}
                    >
                      <Check className="w-3 h-3 text-white" />
                    </div>
                  ) : (
                    <Circle className={`w-5 h-5 ${isCurrent ? "text-accent" : "text-muted-foreground"}`} />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className={`text-sm font-semibold ${isCurrent ? "text-foreground" : "text-muted-foreground"}`}>
                    {member.human.role}
                  </div>

                  {selection && (
                    <div
                      className={`text-xs font-medium mt-0.5 ${
                        selection.type === "human"
                          ? "text-zinc-400"
                          : selection.type === "hybrid"
                            ? "text-purple-400"
                            : "text-accent"
                      }`}
                    >
                      {selection.type === "human"
                        ? "Human"
                        : selection.type === "hybrid"
                          ? "Hybrid"
                          : selection.name || "AI"}
                    </div>
                  )}
                </div>

                {selection && (
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <DollarSign className="w-3 h-3" />
                      <span>{selection.cost}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{selection.time}</span>
                    </div>
                  </div>
                )}
              </div>
            </motion.button>
          )
        })}
      </div>

      {totals && (
        <div className="p-6 border-t border-border bg-card space-y-4">
          <div className="text-xs font-mono text-muted-foreground mb-3">PROJECT SUMMARY</div>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Team Size</span>
              <span className="text-sm font-semibold">{selections.length} roles</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Composition</span>
              <div className="text-xs font-mono space-x-2">
                {totals.humanCount > 0 && <span className="text-zinc-400">{totals.humanCount}H</span>}
                {totals.hybridCount > 0 && <span className="text-purple-400">{totals.hybridCount}Hyb</span>}
                {totals.aiCount > 0 && <span className="text-accent">{totals.aiCount}AI</span>}
              </div>
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-border">
              <span className="text-sm text-muted-foreground">Est. Timeline</span>
              <span className="text-sm font-bold text-accent">{totals.projectWeeks} weeks</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Annual Cost</span>
              <span className="text-sm font-bold text-accent">
                {totals.totalAnnualCost > 0 ? `$${(totals.totalAnnualCost / 1000).toFixed(0)}k` : "Pay-as-you-go"}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
