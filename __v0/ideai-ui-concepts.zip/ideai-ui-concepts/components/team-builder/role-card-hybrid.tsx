"use client"

import { motion } from "framer-motion"
import { Users, Bot, DollarSign, Clock, Zap, CheckCircle2 } from "lucide-react"
import type { TeamMember } from "./types"

type Props = {
  member: TeamMember
  isHovered: boolean
  onHover: () => void
  onLeave: () => void
  onSelect: () => void
}

export function RoleCardHybrid({ member, isHovered, onHover, onLeave, onSelect }: Props) {
  if (!member.hybrid) return null

  return (
    <motion.button
      onClick={onSelect}
      onHoverStart={onHover}
      onHoverEnd={onLeave}
      className="relative group cursor-pointer text-left h-full"
    >
      <motion.div
        className="h-full p-8 rounded-2xl border-2 border-accent/50 bg-gradient-to-br from-accent/10 to-card relative overflow-hidden transition-all duration-500"
        style={{
          transform: isHovered ? "scale(1.05)" : "scale(1)",
        }}
      >
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-accent/10 via-transparent to-accent/10"
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY }}
        />

        <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-accent/20 text-accent text-xs font-mono border border-accent/40">
          Best of Both
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-full bg-accent/20 border-2 border-accent flex items-center justify-center relative">
              <Users className="w-5 h-5 text-accent absolute -left-1 -top-0.5" />
              <Bot className="w-5 h-5 text-accent absolute left-1 top-0.5" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-foreground">Hybrid Mode</h3>
              <p className="text-sm text-accent font-mono">Human + AI</p>
            </div>
          </div>

          <p className="text-foreground/90 mb-6 text-sm leading-relaxed">{member.hybrid.description}</p>

          <div className="space-y-4 mb-6">
            <div className="flex items-center justify-between py-2 border-b border-accent/20">
              <span className="text-sm text-foreground/80 flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-accent" />
                Combined Cost
              </span>
              <span className="font-mono font-bold text-accent">{member.hybrid.cost}</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-accent/20">
              <span className="text-sm text-foreground/80 flex items-center gap-2">
                <Clock className="w-4 h-4 text-accent" />
                Human Oversight
              </span>
              <span className="font-mono text-accent">{member.hybrid.time}</span>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{
              opacity: isHovered ? 1 : 0,
              height: isHovered ? "auto" : 0,
            }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="pt-4 border-t border-accent/20 space-y-3">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-4 h-4 text-accent" />
                <span className="text-xs font-mono text-accent uppercase">Hybrid Benefits</span>
              </div>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-accent mt-0.5" />
                  <span>AI speed with human quality control</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-accent mt-0.5" />
                  <span>85% cost savings vs full-time</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-accent mt-0.5" />
                  <span>Human judgment on critical decisions</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-accent mt-0.5" />
                  <span>5-10x faster than traditional</span>
                </li>
              </ul>
            </div>
          </motion.div>

          {!isHovered && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-xs text-accent/60 font-mono text-center pt-4"
            >
              Hover to see benefits
            </motion.p>
          )}
        </div>
      </motion.div>
    </motion.button>
  )
}
