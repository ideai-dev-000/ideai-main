export type TeamMember = {
  id: string
  human: {
    role: string
    cost: string
    time: string
    pros: string[]
    challenges: string[]
  }
  ai: {
    name: string
    personality: string
    cost: string
    time: string
    description: string
    pros: string[]
  }
  hybrid?: {
    cost: string
    time: string
    description: string
    dailyHours: number
  }
}

export type Selection = {
  roleId: string
  type: "human" | "ai" | "hybrid"
  role: string
  cost: string
  time: string
  name?: string
}

export type TeamMode = "2-part" | "3-part"
