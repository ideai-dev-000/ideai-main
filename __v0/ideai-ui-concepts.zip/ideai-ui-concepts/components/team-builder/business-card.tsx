"use client"

import { motion } from "framer-motion"
import { Users, Bot, Sparkles } from "lucide-react"
import type { Selection } from "./types"

type UserType = "human" | "cyborg" | "bot"

type Props = {
  selections: Selection[]
}

export function BusinessCard({ selections }: Props) {
  const calculateUserType = (): UserType => {
    const humanCount = selections.filter((s) => s.type === "human").length
    const aiCount = selections.filter((s) => s.type === "ai").length
    const hybridCount = selections.filter((s) => s.type === "hybrid").length

    if (humanCount === selections.length) return "human"
    if (aiCount === selections.length) return "bot"
    return "cyborg"
  }

  const userType = calculateUserType()

  const getTypeConfig = () => {
    switch (userType) {
      case "human":
        return {
          title: "Traditional Project Manager",
          icon: Users,
          color: "text-muted-foreground",
          bg: "bg-muted/50",
          border: "border-border",
          credential: "Certified in Legacy Methods",
        }
      case "bot":
        return {
          title: "AI-First Project Lead",
          icon: Bot,
          color: "text-accent",
          bg: "bg-accent/10",
          border: "border-accent",
          credential: "Powered by Next-Gen AI",
        }
      case "cyborg":
        return {
          title: "Hybrid Innovation Leader",
          icon: Sparkles,
          color: "text-accent",
          bg: "bg-gradient-to-br from-accent/20 to-card",
          border: "border-accent/50",
          credential: "Human Wisdom × AI Speed",
        }
    }
  }

  const config = getTypeConfig()
  const Icon = config.icon

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md mx-auto">
      <div className="text-center mb-4">
        <p className="text-sm text-muted-foreground font-mono">Your Project Identity</p>
      </div>
      <div className={`relative p-8 rounded-2xl border-2 ${config.border} ${config.bg} backdrop-blur-sm`}>
        <div className="flex items-start gap-6">
          <div
            className={`w-16 h-16 rounded-full ${config.bg} border-2 ${config.border} flex items-center justify-center`}
          >
            <Icon className={`w-8 h-8 ${config.color}`} />
          </div>
          <div className="flex-1">
            <h3 className={`text-2xl font-bold mb-1 ${config.color}`}>{config.title}</h3>
            <p className="text-sm text-muted-foreground mb-4">{config.credential}</p>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Team Size:</span>
                <span className="font-mono font-bold">{selections.length} roles</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Approach:</span>
                <span className="font-mono font-bold capitalize">{userType}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-border">
          <div className="grid grid-cols-3 gap-4 text-center text-xs">
            <div>
              <div className="font-bold text-lg">{selections.filter((s) => s.type === "human").length}</div>
              <div className="text-muted-foreground">Human</div>
            </div>
            <div>
              <div className="font-bold text-lg">{selections.filter((s) => s.type === "hybrid").length}</div>
              <div className="text-muted-foreground">Hybrid</div>
            </div>
            <div>
              <div className={`font-bold text-lg ${config.color}`}>
                {selections.filter((s) => s.type === "ai").length}
              </div>
              <div className="text-muted-foreground">AI</div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
