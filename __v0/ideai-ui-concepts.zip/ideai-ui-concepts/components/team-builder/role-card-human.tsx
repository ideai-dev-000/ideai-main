"use client"

import { motion } from "framer-motion"
import { Users, DollarSign, Clock, CheckCircle2, AlertCircle } from "lucide-react"
import type { TeamMember } from "./types"

type Props = {
  member: TeamMember
  isHovered: boolean
  onHover: () => void
  onLeave: () => void
  onSelect: () => void
}

export function RoleCardHuman({ member, isHovered, onHover, onLeave, onSelect }: Props) {
  return (
    <motion.button
      onClick={onSelect}
      onHoverStart={onHover}
      onHoverEnd={onLeave}
      className="relative group cursor-pointer text-left h-full"
    >
      <motion.div
        className="h-full p-8 rounded-2xl border-2 border-border bg-muted/30 backdrop-blur-sm relative overflow-hidden transition-all duration-500"
        style={{
          transform: isHovered ? "scale(1.02)" : "scale(1)",
          filter: isHovered ? "grayscale(0.5)" : "grayscale(1)",
        }}
      >
        {/* Isomorphic background pattern */}
        <div className="absolute inset-0 opacity-5">
          <div
            className="w-full h-full"
            style={{
              backgroundImage:
                "repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,.03) 10px, rgba(255,255,255,.03) 20px)",
            }}
          />
        </div>

        <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-destructive/20 text-destructive text-xs font-mono border border-destructive/30">
          Replaced
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-full bg-muted border-2 border-border flex items-center justify-center">
              <Users className="w-6 h-6 text-muted-foreground" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-muted-foreground">{member.human.role}</h3>
              <p className="text-sm text-muted-foreground/60 font-mono">Traditional Approach</p>
            </div>
          </div>

          <div className="space-y-4 mb-6">
            <div className="flex items-center justify-between py-2 border-b border-border/50">
              <span className="text-sm text-muted-foreground/80 flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Annual Cost
              </span>
              <span className="font-mono font-bold text-muted-foreground">{member.human.cost}</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-border/50">
              <span className="text-sm text-muted-foreground/80 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Timeline
              </span>
              <span className="font-mono text-muted-foreground">{member.human.time}</span>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{
              opacity: isHovered ? 1 : 0,
              height: isHovered ? "auto" : 0,
            }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="pt-4 border-t border-border/50 space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle2 className="w-4 h-4 text-green-500/70" />
                  <span className="text-xs font-mono text-muted-foreground uppercase">Pros</span>
                </div>
                <ul className="space-y-1">
                  {member.human.pros.map((pro, i) => (
                    <li key={i} className="text-sm text-muted-foreground/80 pl-6">
                      • {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <AlertCircle className="w-4 h-4 text-destructive/70" />
                  <span className="text-xs font-mono text-muted-foreground uppercase">Challenges</span>
                </div>
                <ul className="space-y-1">
                  {member.human.challenges.map((challenge, i) => (
                    <li key={i} className="text-sm text-muted-foreground/80 pl-6">
                      • {challenge}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>

          {!isHovered && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-xs text-muted-foreground/60 font-mono text-center pt-4"
            >
              Hover to see details
            </motion.p>
          )}
        </div>
      </motion.div>
    </motion.button>
  )
}
