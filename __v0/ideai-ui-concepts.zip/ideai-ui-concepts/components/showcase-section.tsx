"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

const showcaseItems = [
  {
    category: "Web Apps",
    example: "E-commerce Platform",
    description: "Full-featured online store with payment processing, inventory management, and analytics.",
    color: "from-blue-500/20 to-cyan-500/20",
  },
  {
    category: "Mobile Apps",
    example: "Social Media App",
    description: "Native iOS and Android app with real-time messaging, media sharing, and user profiles.",
    color: "from-purple-500/20 to-pink-500/20",
  },
  {
    category: "Games",
    example: "3D Puzzle Game",
    description: "Interactive WebGL game with physics, animations, and multiplayer capabilities.",
    color: "from-orange-500/20 to-red-500/20",
  },
  {
    category: "Content",
    example: "Marketing Campaign",
    description: "Complete campaign with landing pages, email sequences, and social media content.",
    color: "from-green-500/20 to-emerald-500/20",
  },
]

function ShowcaseCard({ item, index }: { item: (typeof showcaseItems)[0]; index: number }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.3 })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.8, delay: index * 0.2 }}
      className="group relative"
    >
      <div
        className={`relative p-8 rounded-2xl border border-border bg-gradient-to-br ${item.color} hover:border-accent/50 transition-all duration-300 overflow-hidden`}
      >
        {/* Category label */}
        <div className="inline-flex px-3 py-1 rounded-full bg-background/80 backdrop-blur-sm text-xs font-mono text-accent mb-4 border border-accent/20">
          {item.category}
        </div>

        {/* Content */}
        <h3 className="text-2xl font-bold mb-3">{item.example}</h3>
        <p className="text-muted-foreground leading-relaxed">{item.description}</p>

        {/* Decorative element */}
        <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-accent/5 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-500" />
      </div>
    </motion.div>
  )
}

export function ShowcaseSection() {
  return (
    <section id="examples" className="py-32 px-6 relative">
      <div className="container mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6 text-balance">
            Build anything.
            <br />
            <span className="text-muted-foreground">Without limits.</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
            From simple prototypes to complex applications, Ideai handles it all.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {showcaseItems.map((item, index) => (
            <ShowcaseCard key={item.example} item={item} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}
