"use client"

import { motion } from "framer-motion"
import { Code2, Lightbulb, Sparkles, Zap } from "lucide-react"

const features = [
  {
    icon: Lightbulb,
    title: "Idea to Code",
    description:
      "Describe what you want to build in natural language. Ideai understands intent and generates production-ready code.",
  },
  {
    icon: Code2,
    title: "Full-Stack IDE",
    description:
      "Complete development environment in your browser. Write, test, and deploy without leaving the platform.",
  },
  {
    icon: Sparkles,
    title: "AI-Powered",
    description:
      "Advanced AI models that understand context, patterns, and best practices to accelerate your development.",
  },
  {
    icon: Zap,
    title: "Instant Preview",
    description: "See your ideas come to life in real-time. No setup, no configuration, just pure creation.",
  },
]

export function FeatureGrid() {
  return (
    <section id="features" className="py-32 px-6">
      <div className="container mx-auto max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6 text-balance">
            Everything you need.
            <br />
            <span className="text-muted-foreground">Nothing you don't.</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
            {`Ideai combines the best of development tools with cutting-edge AI to create the ideal workflow.`}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative"
            >
              <div className="relative h-full p-8 rounded-2xl border border-border bg-card hover:border-accent/50 transition-all duration-300">
                {/* Icon */}
                <div className="mb-6 inline-flex p-3 rounded-xl bg-accent/10 text-accent group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="w-6 h-6" />
                </div>

                {/* Content */}
                <h3 className="text-2xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>

                {/* Hover effect */}
                <div className="absolute inset-0 rounded-2xl bg-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 -z-10" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
