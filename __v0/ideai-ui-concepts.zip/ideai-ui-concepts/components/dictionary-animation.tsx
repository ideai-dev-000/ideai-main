"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"

interface DictionaryEntry {
  word: string
  pronunciation: string
  partOfSpeech: string
  definition: string
  highlight?: boolean
}

const entries: DictionaryEntry[] = [
  {
    word: "IDE",
    pronunciation: "/ˌaɪ diː ˈiː/",
    partOfSpeech: "noun",
    definition:
      "Integrated Development Environment. A software application providing comprehensive facilities for software development.",
    highlight: true,
  },
  {
    word: "IDEA",
    pronunciation: "/aɪˈdɪə/",
    partOfSpeech: "noun",
    definition: "A thought or suggestion as to a possible course of action. The conception of something to be created.",
    highlight: true,
  },
  {
    word: "AI",
    pronunciation: "/ˌeɪ ˈaɪ/",
    partOfSpeech: "noun",
    definition:
      "Artificial Intelligence. The theory and development of computer systems able to perform tasks requiring human intelligence.",
    highlight: true,
  },
  {
    word: "IDEAL",
    pronunciation: "/aɪˈdɪəl/",
    partOfSpeech: "adjective",
    definition: "Satisfying one's conception of what is perfect. Most suitable. The highest standard of excellence.",
    highlight: true,
  },
  {
    word: "Ideai",
    pronunciation: "/aɪˈdiː eɪ aɪ/",
    partOfSpeech: "noun",
    definition:
      "Where IDE meets AI. The synthesis of development environments, human creativity, and artificial intelligence to manifest ideas into reality.",
    highlight: true,
  },
]

function TypewriterText({ text, delay = 0, onComplete }: { text: string; delay?: number; onComplete?: () => void }) {
  const [displayText, setDisplayText] = useState("")

  useEffect(() => {
    setDisplayText("")
    let currentIndex = 0
    const startTimer = setTimeout(() => {
      const interval = setInterval(() => {
        if (currentIndex <= text.length) {
          setDisplayText(text.slice(0, currentIndex))
          currentIndex++
        } else {
          clearInterval(interval)
          if (onComplete) onComplete()
        }
      }, 30)
      return () => clearInterval(interval)
    }, delay)

    return () => clearTimeout(startTimer)
  }, [text, delay, onComplete])

  return <span>{displayText}</span>
}

export function DictionaryAnimation() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [showDetails, setShowDetails] = useState(false)
  const [isComplete, setIsComplete] = useState(false)

  useEffect(() => {
    setShowDetails(false)

    const detailsTimer = setTimeout(() => {
      setShowDetails(true)
    }, 1200)

    if (currentIndex < entries.length - 1) {
      const timer = setTimeout(() => {
        setCurrentIndex(currentIndex + 1)
      }, 2800)
      return () => {
        clearTimeout(timer)
        clearTimeout(detailsTimer)
      }
    } else if (!isComplete) {
      setTimeout(() => setIsComplete(true), 1500)
    }

    return () => clearTimeout(detailsTimer)
  }, [currentIndex, isComplete])

  const currentEntry = entries[currentIndex]

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center overflow-hidden">
      {/* Background grid pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0a0a0a_1px,transparent_1px),linear-gradient(to_bottom,#0a0a0a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,#000_70%,transparent_100%)]" />

      <div className="relative z-10 w-full max-w-4xl px-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -20 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="relative"
          >
            <div className="relative min-h-[400px] rounded-2xl border border-accent/20 bg-black/40 backdrop-blur-sm p-12 shadow-2xl">
              {/* Glowing accent border */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-accent/20 via-transparent to-accent/10 opacity-50" />

              <div className="relative space-y-6">
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                  className="flex items-baseline gap-4"
                >
                  <h2
                    className={`font-mono text-6xl md:text-7xl font-bold tracking-tight ${
                      currentEntry.word === "Ideai" ? "text-accent" : "text-foreground"
                    }`}
                  >
                    <TypewriterText text={currentEntry.word} delay={100} />
                  </h2>
                </motion.div>

                {showDetails && (
                  <>
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3 }}
                      className="text-muted-foreground text-xl font-mono"
                    >
                      {currentEntry.pronunciation}
                    </motion.div>

                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.1, duration: 0.3 }}
                      className="text-accent text-base font-medium italic tracking-wide"
                    >
                      {currentEntry.partOfSpeech}
                    </motion.div>

                    {/* Divider line */}
                    <motion.div
                      initial={{ scaleX: 0 }}
                      animate={{ scaleX: 1 }}
                      transition={{ delay: 0.2, duration: 0.4 }}
                      className="h-px bg-gradient-to-r from-accent/50 via-accent/20 to-transparent origin-left"
                    />

                    <motion.p
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3, duration: 0.3 }}
                      className="text-muted-foreground text-lg leading-relaxed"
                    >
                      {currentEntry.definition}
                    </motion.p>
                  </>
                )}
              </div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="absolute bottom-6 right-6 flex gap-2"
              >
                {entries.map((_, index) => (
                  <div
                    key={index}
                    className={`h-1.5 rounded-full transition-all duration-500 ${
                      index === currentIndex
                        ? "w-8 bg-accent"
                        : index < currentIndex
                          ? "w-8 bg-accent/40"
                          : "w-4 bg-accent/10"
                    }`}
                  />
                ))}
              </motion.div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Final synthesis message */}
        {isComplete && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="mt-16 text-center"
          >
            <div className="inline-flex items-center gap-2 text-sm text-accent font-mono mb-6">
              <div className="w-2 h-2 bg-accent rounded-full animate-pulse" />
              SYNTHESIS COMPLETE
            </div>
            <p className="text-2xl md:text-3xl text-foreground font-light leading-relaxed text-balance">
              {`Transform any `}
              <span className="font-bold text-accent">idea</span>
              {` into reality with the power of an `}
              <span className="font-bold text-accent">IDE</span>
              {` enhanced by `}
              <span className="font-bold text-accent">AI</span>
              {`. The `}
              <span className="font-bold text-accent">ideal</span>
              {` development experience.`}
            </p>
          </motion.div>
        )}
      </div>

      {/* Floating accent elements */}
      <motion.div
        animate={{
          rotate: 360,
        }}
        transition={{
          duration: 20,
          repeat: Number.POSITIVE_INFINITY,
          ease: "linear",
        }}
        className="absolute top-20 right-20 w-64 h-64 bg-accent/5 rounded-full blur-3xl"
      />
      <motion.div
        animate={{
          rotate: -360,
        }}
        transition={{
          duration: 25,
          repeat: Number.POSITIVE_INFINITY,
          ease: "linear",
        }}
        className="absolute bottom-20 left-20 w-96 h-96 bg-accent/5 rounded-full blur-3xl"
      />
    </div>
  )
}
