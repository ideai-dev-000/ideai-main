"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Navigation } from "@/components/navigation"
import { Users, Bot, Brain, Building2, Package, Layers, Sparkles, Zap, ChevronRight } from "lucide-react"

type Category = "team" | "models" | "partners" | "libraries" | "frameworks" | "tools"

type DirectoryItem = {
  id: string
  name: string
  role: string
  description: string
  icon: any
  color: string
  bg: string
  stats?: { label: string; value: string }[]
}

const directory: Record<Category, DirectoryItem[]> = {
  team: [
    {
      id: "alex-founder",
      name: "Alex Chen",
      role: "Founder & CEO",
      description: "Visionary leader driving AI innovation",
      icon: Users,
      color: "text-blue-400",
      bg: "bg-blue-500/10",
      stats: [
        { label: "Founded", value: "2024" },
        { label: "Vision", value: "AI-First" },
      ],
    },
    {
      id: "bot-architect",
      name: "Architect Bot",
      role: "System Design AI",
      description: "Creates optimal architectures in seconds",
      icon: Bot,
      color: "text-accent",
      bg: "bg-accent/10",
      stats: [
        { label: "Speed", value: "10x" },
        { label: "Accuracy", value: "99.8%" },
      ],
    },
    {
      id: "bot-dev",
      name: "Dev Bot",
      role: "Full-Stack AI Engineer",
      description: "Writes production code 24/7",
      icon: Bot,
      color: "text-accent",
      bg: "bg-accent/10",
      stats: [
        { label: "Lines/Day", value: "50K+" },
        { label: "Bugs", value: "Near 0" },
      ],
    },
    {
      id: "bot-qa",
      name: "QA Bot",
      role: "Quality Assurance AI",
      description: "Continuous testing and validation",
      icon: Bot,
      color: "text-accent",
      bg: "bg-accent/10",
      stats: [
        { label: "Tests/Hour", value: "1000+" },
        { label: "Coverage", value: "100%" },
      ],
    },
  ],
  models: [
    {
      id: "gpt-4",
      name: "GPT-4",
      role: "Large Language Model",
      description: "OpenAI's flagship reasoning model",
      icon: Brain,
      color: "text-green-400",
      bg: "bg-green-500/10",
      stats: [
        { label: "Params", value: "1.7T" },
        { label: "Speed", value: "Fast" },
      ],
    },
    {
      id: "claude",
      name: "Claude 3.5 Sonnet",
      role: "Advanced LLM",
      description: "Anthropic's latest reasoning powerhouse",
      icon: Brain,
      color: "text-purple-400",
      bg: "bg-purple-500/10",
      stats: [
        { label: "Context", value: "200K" },
        { label: "Quality", value: "Elite" },
      ],
    },
    {
      id: "gemini",
      name: "Gemini Pro",
      role: "Multimodal AI",
      description: "Google's versatile model",
      icon: Brain,
      color: "text-orange-400",
      bg: "bg-orange-500/10",
      stats: [
        { label: "Modality", value: "Multi" },
        { label: "Speed", value: "Ultra" },
      ],
    },
    {
      id: "phi",
      name: "Phi-3",
      role: "Small Language Model",
      description: "Microsoft's efficient SLM",
      icon: Sparkles,
      color: "text-cyan-400",
      bg: "bg-cyan-500/10",
      stats: [
        { label: "Size", value: "3.8B" },
        { label: "Cost", value: "Low" },
      ],
    },
  ],
  partners: [
    {
      id: "vercel",
      name: "Vercel",
      role: "Infrastructure Partner",
      description: "Next-gen deployment platform",
      icon: Building2,
      color: "text-white",
      bg: "bg-white/10",
      stats: [
        { label: "Uptime", value: "99.99%" },
        { label: "Edge", value: "Global" },
      ],
    },
    {
      id: "google",
      name: "Google Cloud",
      role: "Cloud Infrastructure",
      description: "Enterprise-grade cloud services",
      icon: Building2,
      color: "text-blue-400",
      bg: "bg-blue-500/10",
      stats: [
        { label: "Scale", value: "Unlimited" },
        { label: "AI", value: "Vertex AI" },
      ],
    },
    {
      id: "openai",
      name: "OpenAI",
      role: "AI Model Provider",
      description: "Leading AI research and deployment",
      icon: Building2,
      color: "text-green-400",
      bg: "bg-green-500/10",
      stats: [
        { label: "Models", value: "GPT-4+" },
        { label: "API", value: "Stable" },
      ],
    },
    {
      id: "anthropic",
      name: "Anthropic",
      role: "AI Safety Partner",
      description: "Responsible AI development",
      icon: Building2,
      color: "text-purple-400",
      bg: "bg-purple-500/10",
      stats: [
        { label: "Safety", value: "First" },
        { label: "Ethics", value: "Core" },
      ],
    },
  ],
  libraries: [
    {
      id: "react",
      name: "React 19",
      role: "UI Library",
      description: "The foundation of modern web UIs",
      icon: Package,
      color: "text-cyan-400",
      bg: "bg-cyan-500/10",
      stats: [
        { label: "Version", value: "19.2" },
        { label: "Type", value: "Core" },
      ],
    },
    {
      id: "framer",
      name: "Framer Motion",
      role: "Animation Library",
      description: "Smooth, production-ready animations",
      icon: Package,
      color: "text-pink-400",
      bg: "bg-pink-500/10",
      stats: [
        { label: "Perf", value: "60fps" },
        { label: "Easy", value: "Yes" },
      ],
    },
    {
      id: "ai-sdk",
      name: "Vercel AI SDK",
      role: "AI Integration",
      description: "Build AI apps with ease",
      icon: Package,
      color: "text-accent",
      bg: "bg-accent/10",
      stats: [
        { label: "Models", value: "All" },
        { label: "Stream", value: "Yes" },
      ],
    },
    {
      id: "shadcn",
      name: "shadcn/ui",
      role: "Component Library",
      description: "Beautiful, accessible components",
      icon: Package,
      color: "text-zinc-400",
      bg: "bg-zinc-500/10",
      stats: [
        { label: "Style", value: "Custom" },
        { label: "A11y", value: "Full" },
      ],
    },
  ],
  frameworks: [
    {
      id: "nextjs",
      name: "Next.js 16",
      role: "React Framework",
      description: "The React framework for production",
      icon: Layers,
      color: "text-white",
      bg: "bg-white/10",
      stats: [
        { label: "Render", value: "Hybrid" },
        { label: "Perf", value: "Elite" },
      ],
    },
    {
      id: "tailwind",
      name: "Tailwind CSS",
      role: "Styling Framework",
      description: "Utility-first CSS framework",
      icon: Layers,
      color: "text-cyan-400",
      bg: "bg-cyan-500/10",
      stats: [
        { label: "Size", value: "Tiny" },
        { label: "DX", value: "Great" },
      ],
    },
    {
      id: "typescript",
      name: "TypeScript",
      role: "Language",
      description: "Type-safe JavaScript",
      icon: Layers,
      color: "text-blue-400",
      bg: "bg-blue-500/10",
      stats: [
        { label: "Safety", value: "100%" },
        { label: "DX", value: "Best" },
      ],
    },
    {
      id: "reactflow",
      name: "React Flow",
      role: "Node-Based UI",
      description: "Build interactive diagrams",
      icon: Layers,
      color: "text-pink-400",
      bg: "bg-pink-500/10",
      stats: [
        { label: "Nodes", value: "Custom" },
        { label: "Perf", value: "High" },
      ],
    },
  ],
  tools: [
    {
      id: "github",
      name: "GitHub",
      role: "Version Control",
      description: "Where the world builds software",
      icon: Zap,
      color: "text-zinc-400",
      bg: "bg-zinc-500/10",
      stats: [
        { label: "Repos", value: "Unlimited" },
        { label: "CI/CD", value: "Built-in" },
      ],
    },
    {
      id: "figma",
      name: "Figma",
      role: "Design Tool",
      description: "Collaborative design platform",
      icon: Zap,
      color: "text-purple-400",
      bg: "bg-purple-500/10",
      stats: [
        { label: "Collab", value: "Real-time" },
        { label: "Dev", value: "Mode" },
      ],
    },
    {
      id: "supabase",
      name: "Supabase",
      role: "Backend Platform",
      description: "Open source Firebase alternative",
      icon: Zap,
      color: "text-green-400",
      bg: "bg-green-500/10",
      stats: [
        { label: "DB", value: "Postgres" },
        { label: "Auth", value: "Built-in" },
      ],
    },
    {
      id: "stripe",
      name: "Stripe",
      role: "Payments",
      description: "Internet payment infrastructure",
      icon: Zap,
      color: "text-indigo-400",
      bg: "bg-indigo-500/10",
      stats: [
        { label: "Global", value: "Yes" },
        { label: "APIs", value: "Best" },
      ],
    },
  ],
}

const categories = [
  { id: "team" as Category, label: "Team & Bots", icon: Users },
  { id: "models" as Category, label: "AI Models", icon: Brain },
  { id: "partners" as Category, label: "Partners", icon: Building2 },
  { id: "libraries" as Category, label: "Libraries", icon: Package },
  { id: "frameworks" as Category, label: "Frameworks", icon: Layers },
  { id: "tools" as Category, label: "Tools", icon: Zap },
]

export default function DirectoryPage() {
  const [activeCategory, setActiveCategory] = useState<Category>("team")

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-background pt-24 pb-16 px-6">
        <div className="container mx-auto">
          {/* Header */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <h1 className="text-5xl font-bold mb-4">
              <span className="text-foreground">Ideai</span> <span className="text-accent">Directory</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Meet our team, discover the AI models we use, and explore our technology partners
            </p>
          </motion.div>

          {/* Category Filters */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="flex flex-wrap justify-center gap-3 mb-12"
          >
            {categories.map((cat) => {
              const Icon = cat.icon
              const isActive = activeCategory === cat.id
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-6 py-3 rounded-full font-medium transition-all flex items-center gap-2 ${
                    isActive
                      ? "bg-accent text-accent-foreground shadow-lg scale-105"
                      : "bg-card text-muted-foreground hover:text-foreground hover:bg-card/80"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {cat.label}
                </button>
              )
            })}
          </motion.div>

          {/* Directory Cards Grid */}
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {directory[activeCategory].map((item, idx) => {
                const Icon = item.icon
                return (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="group relative"
                  >
                    <div className="relative h-full p-6 rounded-2xl border border-border bg-card hover:border-accent/50 transition-all duration-300 hover:shadow-xl hover:shadow-accent/10 hover:-translate-y-1">
                      {/* Icon */}
                      <div
                        className={`w-14 h-14 rounded-xl ${item.bg} border border-border flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                      >
                        <Icon className={`w-7 h-7 ${item.color}`} />
                      </div>

                      {/* Content */}
                      <h3 className="text-xl font-bold mb-1 text-foreground">{item.name}</h3>
                      <p className="text-sm text-accent font-medium mb-2">{item.role}</p>
                      <p className="text-sm text-muted-foreground mb-4">{item.description}</p>

                      {/* Stats */}
                      {item.stats && (
                        <div className="pt-4 border-t border-border grid grid-cols-2 gap-3">
                          {item.stats.map((stat) => (
                            <div key={stat.label}>
                              <div className="text-xs text-muted-foreground">{stat.label}</div>
                              <div className="font-mono font-bold text-sm">{stat.value}</div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Hover Arrow */}
                      <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity">
                        <ChevronRight className="w-5 h-5 text-accent" />
                      </div>
                    </div>
                  </motion.div>
                )
              })}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </>
  )
}
