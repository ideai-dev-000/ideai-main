"use client"

import { Navigation } from "@/components/navigation"
import { motion } from "framer-motion"
import { Swiper, SwiperSlide } from "swiper/react"
import { EffectCoverflow, Pagination, Navigation as SwiperNav, Autoplay } from "swiper/modules"
import { Sparkles, Zap, Target, Rocket, Shield, Globe } from "lucide-react"
import { Button } from "@/components/ui/button"

import "swiper/css"
import "swiper/css/effect-coverflow"
import "swiper/css/pagination"
import "swiper/css/navigation"

const slides = [
  {
    icon: Sparkles,
    title: "AI-Powered Creation",
    description: "Transform ideas into production-ready applications with advanced AI agents",
    gradient: "from-violet-500/20 to-purple-500/20",
    accent: "text-violet-400",
  },
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Deploy in minutes, not months. Our AI agents work 24/7 at machine speed",
    gradient: "from-yellow-500/20 to-orange-500/20",
    accent: "text-yellow-400",
  },
  {
    icon: Target,
    title: "Precision Engineering",
    description: "Every line of code optimized for performance, security, and scalability",
    gradient: "from-red-500/20 to-pink-500/20",
    accent: "text-red-400",
  },
  {
    icon: Rocket,
    title: "Scale Without Limits",
    description: "From MVP to enterprise, grow your application without constraints",
    gradient: "from-blue-500/20 to-cyan-500/20",
    accent: "text-blue-400",
  },
  {
    icon: Shield,
    title: "Enterprise Security",
    description: "Bank-level encryption, SOC2 compliance, and automated security testing",
    gradient: "from-green-500/20 to-emerald-500/20",
    accent: "text-green-400",
  },
  {
    icon: Globe,
    title: "Global Deployment",
    description: "Deploy to edge networks worldwide with automatic CDN optimization",
    gradient: "from-indigo-500/20 to-blue-500/20",
    accent: "text-indigo-400",
  },
]

export default function SlidesPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="container mx-auto px-6 pt-32 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl font-bold mb-4 text-foreground">
            Platform <span className="text-accent">Features</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore the capabilities that make Ideai the future of software development
          </p>
        </motion.div>

        {/* 3D Coverflow Slider */}
        <div className="mb-20">
          <Swiper
            effect="coverflow"
            grabCursor={true}
            centeredSlides={true}
            slidesPerView="auto"
            coverflowEffect={{
              rotate: 50,
              stretch: 0,
              depth: 100,
              modifier: 1,
              slideShadows: false,
            }}
            pagination={{
              clickable: true,
              dynamicBullets: true,
            }}
            navigation={true}
            autoplay={{
              delay: 3000,
              disableOnInteraction: false,
            }}
            modules={[EffectCoverflow, Pagination, SwiperNav, Autoplay]}
            className="py-12"
          >
            {slides.map((slide, index) => (
              <SwiperSlide key={index} style={{ width: "400px" }}>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className={`relative p-8 rounded-3xl border backdrop-blur-xl bg-gradient-to-br ${slide.gradient} border-border/50 h-[400px] flex flex-col items-center justify-center text-center`}
                >
                  <slide.icon className={`w-16 h-16 mb-6 ${slide.accent}`} />
                  <h3 className="text-2xl font-bold mb-4 text-foreground">{slide.title}</h3>
                  <p className="text-muted-foreground mb-6">{slide.description}</p>
                  <Button size="sm" variant="outline" className="mt-auto bg-transparent">
                    Learn More
                  </Button>
                </motion.div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>

        {/* Standard Horizontal Slider */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold mb-8 text-center text-foreground">Use Cases</h2>
          <Swiper
            spaceBetween={30}
            slidesPerView={1}
            breakpoints={{
              640: { slidesPerView: 2 },
              1024: { slidesPerView: 3 },
            }}
            pagination={{
              clickable: true,
            }}
            modules={[Pagination]}
            className="pb-12"
          >
            {[
              { title: "E-Commerce Platform", desc: "Full-stack marketplace with AI recommendations", time: "2 weeks" },
              { title: "SaaS Dashboard", desc: "Analytics platform with real-time data", time: "1 week" },
              { title: "Mobile App", desc: "Cross-platform React Native application", time: "3 weeks" },
              { title: "API Backend", desc: "Scalable microservices architecture", time: "1 week" },
              { title: "Admin Panel", desc: "Complete content management system", time: "1 week" },
              { title: "Landing Page", desc: "High-converting marketing site", time: "2 days" },
            ].map((useCase, index) => (
              <SwiperSlide key={index}>
                <motion.div
                  whileHover={{ y: -5 }}
                  className="p-6 rounded-2xl border backdrop-blur-sm bg-card/50 border-border/50 h-full"
                >
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-xl font-bold text-foreground">{useCase.title}</h3>
                    <span className="text-xs font-mono px-2 py-1 rounded-full bg-accent/20 text-accent">
                      {useCase.time}
                    </span>
                  </div>
                  <p className="text-muted-foreground">{useCase.desc}</p>
                </motion.div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>

        {/* Vertical Slider */}
        <div className="max-w-md mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-center text-foreground">Tech Stack</h2>
          <Swiper
            direction="vertical"
            spaceBetween={20}
            slidesPerView={3}
            centeredSlides={true}
            autoplay={{
              delay: 2000,
              disableOnInteraction: false,
            }}
            modules={[Autoplay]}
            className="h-[400px]"
          >
            {[
              "Next.js 16",
              "React 19",
              "TypeScript",
              "Tailwind CSS",
              "Framer Motion",
              "Vercel AI SDK",
              "Supabase",
              "PostgreSQL",
              "Prisma",
              "tRPC",
            ].map((tech, index) => (
              <SwiperSlide key={index}>
                <motion.div
                  className="flex items-center justify-center h-full rounded-2xl border backdrop-blur-sm bg-card/30 border-border/50"
                  whileHover={{ scale: 1.05 }}
                >
                  <span className="text-xl font-semibold text-foreground">{tech}</span>
                </motion.div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>
    </div>
  )
}
