"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Calendar, Bot, User, Users } from "lucide-react"
import { Navigation } from "@/components/navigation"

interface Task {
  id: string
  name: string
  start: number
  duration: number
  progress: number
  type: "human" | "ai" | "hybrid"
  dependencies?: string[]
}

const projectTasks: Task[] = [
  { id: "1", name: "Discovery & Planning", start: 0, duration: 3, progress: 100, type: "hybrid" },
  { id: "2", name: "Design System", start: 2, duration: 5, progress: 100, type: "ai" },
  { id: "3", name: "Frontend Development", start: 5, duration: 8, progress: 75, type: "ai", dependencies: ["2"] },
  { id: "4", name: "Backend API", start: 6, duration: 6, progress: 60, type: "ai", dependencies: ["1"] },
  { id: "5", name: "Database Setup", start: 7, duration: 4, progress: 80, type: "ai", dependencies: ["4"] },
  { id: "6", name: "AI Model Integration", start: 10, duration: 5, progress: 40, type: "ai", dependencies: ["4"] },
  { id: "7", name: "Testing & QA", start: 13, duration: 4, progress: 20, type: "hybrid", dependencies: ["3", "4"] },
  { id: "8", name: "Security Audit", start: 15, duration: 3, progress: 0, type: "hybrid", dependencies: ["5", "6"] },
  { id: "9", name: "Performance Optimization", start: 16, duration: 2, progress: 0, type: "ai", dependencies: ["3"] },
  {
    id: "10",
    name: "Deployment & Launch",
    start: 18,
    duration: 2,
    progress: 0,
    type: "hybrid",
    dependencies: ["7", "8", "9"],
  },
]

export default function GanttPage() {
  const [zoom, setZoom] = useState(1)
  const [viewStart, setViewStart] = useState(0)
  const weeks = 24
  const dayWidth = 40 * zoom
  const rowHeight = 60

  const getTypeColor = (type: Task["type"]) => {
    switch (type) {
      case "human":
        return "bg-muted"
      case "ai":
        return "bg-accent"
      case "hybrid":
        return "bg-accent/60"
    }
  }

  const getTypeIcon = (type: Task["type"]) => {
    switch (type) {
      case "human":
        return <User className="w-3 h-3" />
      case "ai":
        return <Bot className="w-3 h-3" />
      case "hybrid":
        return <Users className="w-3 h-3" />
    }
  }

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-background pt-16">
        <div className="container mx-auto px-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-4xl font-bold mb-2">Project Timeline</h1>
                <p className="text-muted-foreground">AI-powered Gantt chart with intelligent task scheduling</p>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" onClick={() => setZoom(Math.max(0.5, zoom - 0.25))}>
                  <ZoomOut className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={() => setZoom(Math.min(2, zoom + 0.25))}>
                  <ZoomIn className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={() => setViewStart(Math.max(0, viewStart - 7))}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="icon" onClick={() => setViewStart(Math.min(weeks - 10, viewStart + 7))}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <Card className="overflow-hidden">
              <div className="flex border-b border-border">
                {/* Task Names Column */}
                <div className="w-80 bg-muted/30 border-r border-border flex-shrink-0">
                  <div className="h-16 border-b border-border flex items-center px-6 font-semibold">
                    <Calendar className="w-4 h-4 mr-2" />
                    Tasks
                  </div>
                  {projectTasks.map((task) => (
                    <div
                      key={task.id}
                      className="flex items-center px-6 border-b border-border last:border-b-0"
                      style={{ height: rowHeight }}
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          {getTypeIcon(task.type)}
                          <span className="font-medium text-sm">{task.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {task.type}
                          </Badge>
                          <span className="text-xs text-muted-foreground">{task.progress}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Timeline Grid */}
                <div className="flex-1 overflow-x-auto">
                  <div className="relative">
                    {/* Week Headers */}
                    <div className="h-16 border-b border-border flex">
                      {Array.from({ length: weeks }).map((_, i) => (
                        <div
                          key={i}
                          className="border-r border-border flex items-center justify-center text-xs font-medium text-muted-foreground flex-shrink-0"
                          style={{ width: dayWidth * 7 }}
                        >
                          Week {i + 1}
                        </div>
                      ))}
                    </div>

                    {/* Task Bars */}
                    <div className="relative">
                      {projectTasks.map((task, index) => (
                        <div
                          key={task.id}
                          className="border-b border-border last:border-b-0 relative"
                          style={{ height: rowHeight }}
                        >
                          {/* Background Grid */}
                          <div className="absolute inset-0 flex">
                            {Array.from({ length: weeks * 7 }).map((_, i) => (
                              <div
                                key={i}
                                className="border-r border-border/30 flex-shrink-0"
                                style={{ width: dayWidth }}
                              />
                            ))}
                          </div>

                          {/* Task Bar */}
                          <motion.div
                            initial={{ scaleX: 0 }}
                            animate={{ scaleX: 1 }}
                            transition={{ duration: 0.8, delay: index * 0.1 }}
                            className="absolute top-1/2 -translate-y-1/2 rounded-lg overflow-hidden shadow-lg"
                            style={{
                              left: task.start * dayWidth * 7,
                              width: task.duration * dayWidth * 7,
                              height: 40,
                            }}
                          >
                            <div className={`h-full ${getTypeColor(task.type)} relative`}>
                              {/* Progress Bar */}
                              <div
                                className="absolute inset-0 bg-foreground/20"
                                style={{ width: `${task.progress}%` }}
                              />
                              <div className="absolute inset-0 flex items-center justify-center">
                                <span className="text-xs font-medium text-foreground mix-blend-difference">
                                  {task.duration}w
                                </span>
                              </div>
                            </div>
                          </motion.div>

                          {/* Dependencies */}
                          {task.dependencies?.map((depId) => {
                            const depTask = projectTasks.find((t) => t.id === depId)
                            if (!depTask) return null
                            const depIndex = projectTasks.indexOf(depTask)

                            return (
                              <svg
                                key={depId}
                                className="absolute pointer-events-none"
                                style={{
                                  top: 0,
                                  left: 0,
                                  width: "100%",
                                  height: "100%",
                                }}
                              >
                                <motion.path
                                  initial={{ pathLength: 0 }}
                                  animate={{ pathLength: 1 }}
                                  transition={{ duration: 0.8, delay: index * 0.1 + 0.3 }}
                                  d={`M ${(depTask.start + depTask.duration) * dayWidth * 7} ${(depIndex - index) * rowHeight + rowHeight / 2} L ${task.start * dayWidth * 7} ${rowHeight / 2}`}
                                  stroke="hsl(var(--muted-foreground))"
                                  strokeWidth="2"
                                  strokeDasharray="4 4"
                                  fill="none"
                                  opacity="0.3"
                                />
                              </svg>
                            )
                          })}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Legend */}
            <div className="flex items-center gap-6 mt-6 justify-center">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-muted" />
                <span className="text-sm text-muted-foreground">Human</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-accent" />
                <span className="text-sm text-muted-foreground">AI Agent</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-accent/60" />
                <span className="text-sm text-muted-foreground">Hybrid (AI + Human)</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  )
}
