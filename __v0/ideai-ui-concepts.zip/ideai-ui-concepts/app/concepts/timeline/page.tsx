"use client"

import { Navigation } from "@/components/navigation"
import { motion, useInView } from "framer-motion"
import { CheckCircle2, Circle, ArrowRight } from "lucide-react"
import { useRef } from "react"

interface TimelineEvent {
  date: string
  title: string
  description: string
  status: "completed" | "active" | "upcoming"
  details: string[]
}

const timelineEvents: TimelineEvent[] = [
  {
    date: "Q1 2024",
    title: "Project Initiation",
    description: "Ideai platform concept and market research",
    status: "completed",
    details: ["Market analysis complete", "User interviews conducted", "Initial wireframes approved"],
  },
  {
    date: "Q2 2024",
    title: "AI Agent Development",
    description: "Building core AI agents for development workflow",
    status: "completed",
    details: ["Sales AI agent deployed", "Dev AI agent trained", "QA automation implemented"],
  },
  {
    date: "Q3 2024",
    title: "Beta Testing",
    description: "Private beta with select partners",
    status: "completed",
    details: ["100+ beta users onboarded", "Feedback loop established", "Performance metrics tracked"],
  },
  {
    date: "Q4 2024",
    title: "Public Launch",
    description: "Full platform release to market",
    status: "active",
    details: ["Marketing campaign launched", "Onboarding flow optimized", "Customer support scaled"],
  },
  {
    date: "Q1 2025",
    title: "Enterprise Features",
    description: "Advanced collaboration and security features",
    status: "upcoming",
    details: ["SSO integration", "Advanced permissions", "Audit logging"],
  },
  {
    date: "Q2 2025",
    title: "AI Model Training",
    description: "Custom AI models for specific industries",
    status: "upcoming",
    details: ["Healthcare vertical", "Finance vertical", "E-commerce vertical"],
  },
  {
    date: "Q3 2025",
    title: "Global Expansion",
    description: "Multi-language support and regional data centers",
    status: "upcoming",
    details: ["EU data center", "APAC expansion", "10+ language support"],
  },
]

function TimelineItem({ event, index }: { event: TimelineEvent; index: number }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className={`flex gap-8 items-start ${index % 2 === 0 ? "flex-row" : "flex-row-reverse"}`}
    >
      {/* Content */}
      <div className={`flex-1 ${index % 2 === 0 ? "text-right" : "text-left"}`}>
        <div className="inline-block">
          <motion.div
            whileHover={{ scale: 1.02 }}
            className={`p-6 rounded-2xl border backdrop-blur-sm transition-all ${
              event.status === "completed"
                ? "bg-accent/5 border-accent/30"
                : event.status === "active"
                  ? "bg-primary/5 border-primary/30"
                  : "bg-muted/30 border-muted-foreground/20"
            }`}
          >
            <div
              className={`text-xs font-mono mb-2 ${
                event.status === "completed"
                  ? "text-accent"
                  : event.status === "active"
                    ? "text-primary"
                    : "text-muted-foreground"
              }`}
            >
              {event.date}
            </div>
            <h3 className="text-xl font-bold mb-2 text-foreground">{event.title}</h3>
            <p className="text-sm text-muted-foreground mb-4">{event.description}</p>
            <ul className={`text-xs space-y-1 ${index % 2 === 0 ? "text-right" : "text-left"}`}>
              {event.details.map((detail, i) => (
                <li key={i} className="flex items-center gap-2 text-muted-foreground">
                  {index % 2 === 0 ? (
                    <>
                      <span>{detail}</span>
                      <ArrowRight className="w-3 h-3" />
                    </>
                  ) : (
                    <>
                      <ArrowRight className="w-3 h-3" />
                      <span>{detail}</span>
                    </>
                  )}
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>

      {/* Timeline indicator */}
      <div className="relative flex flex-col items-center">
        <div
          className={`w-10 h-10 rounded-full border-2 flex items-center justify-center z-10 transition-all ${
            event.status === "completed"
              ? "bg-accent border-accent text-accent-foreground"
              : event.status === "active"
                ? "bg-primary border-primary text-primary-foreground animate-pulse"
                : "bg-background border-muted-foreground/30 text-muted-foreground"
          }`}
        >
          {event.status === "completed" ? (
            <CheckCircle2 className="w-5 h-5" />
          ) : event.status === "active" ? (
            <Circle className="w-5 h-5 fill-current" />
          ) : (
            <Circle className="w-5 h-5" />
          )}
        </div>
        {index < timelineEvents.length - 1 && (
          <div className={`w-0.5 h-32 ${event.status === "completed" ? "bg-accent/30" : "bg-muted-foreground/20"}`} />
        )}
      </div>

      {/* Spacer */}
      <div className="flex-1" />
    </motion.div>
  )
}

export default function TimelinePage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <div className="container mx-auto px-6 pt-32 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl font-bold mb-4 text-foreground">
            Product <span className="text-accent">Timeline</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Track the journey of Ideai from concept to global AI platform
          </p>
        </motion.div>

        <div className="max-w-6xl mx-auto">
          {timelineEvents.map((event, index) => (
            <TimelineItem key={index} event={event} index={index} />
          ))}
        </div>

        {/* Legend */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-20 flex justify-center gap-8"
        >
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-accent" />
            <span className="text-sm text-muted-foreground">Completed</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-primary animate-pulse" />
            <span className="text-sm text-muted-foreground">In Progress</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-muted-foreground/30" />
            <span className="text-sm text-muted-foreground">Upcoming</span>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
