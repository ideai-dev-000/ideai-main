"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Sparkles,
  ShoppingCart,
  MessageSquare,
  Calendar,
  FileText,
  Database,
  Zap,
  Clock,
  DollarSign,
} from "lucide-react"
import { Navigation } from "@/components/navigation"

const templates = [
  {
    id: "saas",
    name: "SaaS Starter",
    description: "Complete SaaS platform with auth, billing, and admin dashboard",
    icon: Sparkles,
    buildTime: "2 days",
    humanTime: "3 months",
    cost: "$450",
    humanCost: "$45,000",
    features: ["Authentication", "Stripe Integration", "Admin Dashboard", "API", "Database"],
    category: "saas",
  },
  {
    id: "ecommerce",
    name: "E-Commerce",
    description: "Full-featured online store with cart, checkout, and inventory",
    icon: ShoppingCart,
    buildTime: "3 days",
    humanTime: "4 months",
    cost: "$680",
    humanCost: "$60,000",
    features: ["Product Catalog", "Shopping Cart", "Payment Gateway", "Order Management", "Analytics"],
    category: "ecommerce",
  },
  {
    id: "chat",
    name: "Chat Platform",
    description: "Real-time messaging with channels, DMs, and file sharing",
    icon: MessageSquare,
    buildTime: "2 days",
    humanTime: "2.5 months",
    cost: "$520",
    humanCost: "$38,000",
    features: ["Real-time Messaging", "Channels", "File Upload", "User Presence", "Notifications"],
    category: "social",
  },
  {
    id: "booking",
    name: "Booking System",
    description: "Appointment scheduling with calendar sync and reminders",
    icon: Calendar,
    buildTime: "1.5 days",
    humanTime: "2 months",
    cost: "$380",
    humanCost: "$30,000",
    features: [
      "Calendar Integration",
      "Booking Management",
      "Email Reminders",
      "Payment Processing",
      "Staff Management",
    ],
    category: "business",
  },
  {
    id: "cms",
    name: "Content CMS",
    description: "Headless CMS with API, media library, and workflow",
    icon: FileText,
    buildTime: "2.5 days",
    humanTime: "3.5 months",
    cost: "$590",
    humanCost: "$52,000",
    features: ["Content Editor", "Media Library", "API Access", "Version Control", "Multi-language"],
    category: "content",
  },
  {
    id: "analytics",
    name: "Analytics Dashboard",
    description: "Custom analytics with visualizations and reports",
    icon: Database,
    buildTime: "2 days",
    humanTime: "2 months",
    cost: "$480",
    humanCost: "$32,000",
    features: ["Data Visualization", "Custom Reports", "Real-time Updates", "Export Options", "User Tracking"],
    category: "analytics",
  },
]

export default function TemplatesPage() {
  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-background pt-16">
        <div className="container mx-auto px-6 py-12">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="mb-8">
              <h1 className="text-4xl font-bold mb-2">SaaS Templates</h1>
              <p className="text-muted-foreground">Pre-built templates generated in days, not months</p>
            </div>

            <Tabs defaultValue="all" className="mb-8">
              <TabsList>
                <TabsTrigger value="all">All Templates</TabsTrigger>
                <TabsTrigger value="saas">SaaS</TabsTrigger>
                <TabsTrigger value="ecommerce">E-Commerce</TabsTrigger>
                <TabsTrigger value="social">Social</TabsTrigger>
                <TabsTrigger value="business">Business</TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {templates.map((template, index) => (
                <motion.div
                  key={template.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full flex flex-col hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
                          <template.icon className="w-5 h-5 text-accent" />
                        </div>
                        <CardTitle className="text-lg">{template.name}</CardTitle>
                      </div>
                      <CardDescription>{template.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="flex-1 flex flex-col">
                      <div className="space-y-4 mb-6">
                        <div className="grid grid-cols-2 gap-3">
                          <div className="bg-muted/30 rounded-lg p-3">
                            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                              <Clock className="w-3 h-3" />
                              AI Build Time
                            </div>
                            <div className="font-semibold text-sm">{template.buildTime}</div>
                          </div>
                          <div className="bg-muted/30 rounded-lg p-3">
                            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                              <DollarSign className="w-3 h-3" />
                              AI Cost
                            </div>
                            <div className="font-semibold text-sm text-accent">{template.cost}</div>
                          </div>
                        </div>

                        <div className="bg-muted/10 rounded-lg p-3 border border-muted">
                          <div className="text-xs text-muted-foreground mb-1">Traditional Development</div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="line-through">{template.humanTime}</span>
                            <span className="line-through">{template.humanCost}</span>
                          </div>
                        </div>

                        <div>
                          <div className="text-xs font-medium mb-2">Features</div>
                          <div className="flex flex-wrap gap-1">
                            {template.features.map((feature) => (
                              <Badge key={feature} variant="outline" className="text-xs">
                                {feature}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>

                      <Button className="w-full mt-auto">
                        <Zap className="w-4 h-4 mr-2" />
                        Build Now
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Comparison Card */}
            <Card className="mt-12 bg-accent/5 border-accent/20">
              <CardContent className="py-8">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold mb-2">The AI Advantage</h3>
                  <p className="text-muted-foreground">See how AI transforms development timelines and costs</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-accent mb-2">95%</div>
                    <div className="text-sm text-muted-foreground">Cost Reduction</div>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-accent mb-2">40x</div>
                    <div className="text-sm text-muted-foreground">Faster Delivery</div>
                  </div>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-accent mb-2">24/7</div>
                    <div className="text-sm text-muted-foreground">Development Time</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </>
  )
}
