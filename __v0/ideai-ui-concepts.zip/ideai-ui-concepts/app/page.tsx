"use client"

import { useState, useEffect } from "react"
import { DictionaryAnimation } from "@/components/dictionary-animation"
import { Navigation } from "@/components/navigation"
import { HeroSection } from "@/components/hero-section"
import { FeatureGrid } from "@/components/feature-grid"
import { ShowcaseSection } from "@/components/showcase-section"
import { CTASection } from "@/components/cta-section"

export default function Page() {
  const [showIntro, setShowIntro] = useState(true)

  useEffect(() => {
    // Show intro animation for 15 seconds, then transition to main site
    const timer = setTimeout(() => {
      setShowIntro(false)
    }, 15000)

    return () => clearTimeout(timer)
  }, [])

  if (showIntro) {
    return (
      <div className="relative">
        <DictionaryAnimation />
        <button
          onClick={() => setShowIntro(false)}
          className="fixed bottom-8 right-8 z-50 px-6 py-3 rounded-full bg-accent text-accent-foreground font-mono text-sm hover:bg-accent/90 transition-colors border border-accent/50"
        >
          Skip to Site →
        </button>
      </div>
    )
  }

  return (
    <main className="relative">
      <Navigation />
      <HeroSection />
      <FeatureGrid />
      <ShowcaseSection />
      <CTASection />

      {/* Footer */}
      <footer className="border-t border-border py-12 px-6">
        <div className="container mx-auto max-w-7xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <span className="font-mono text-xl font-bold tracking-tight">
                <span className="text-foreground">Idea</span>
                <span className="text-accent">i</span>
              </span>
              <span className="text-muted-foreground text-sm">© 2027</span>
            </div>
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-foreground transition-colors">
                Privacy
              </a>
              <a href="#" className="hover:text-foreground transition-colors">
                Terms
              </a>
              <a href="#" className="hover:text-foreground transition-colors">
                Contact
              </a>
            </div>
          </div>
        </div>
      </footer>
    </main>
  )
}
