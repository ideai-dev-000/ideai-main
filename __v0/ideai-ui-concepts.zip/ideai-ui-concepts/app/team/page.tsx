"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Bot, Users, ArrowRight, DollarSign, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Navigation } from "@/components/navigation"
import type { Selection, TeamMode } from "@/components/team-builder/types"
import { RoleCardHuman } from "@/components/team-builder/role-card-human"
import { RoleCardAi } from "@/components/team-builder/role-card-ai"
import { RoleCardHybrid } from "@/components/team-builder/role-card-hybrid"
import { BusinessCard } from "@/components/team-builder/business-card"
import { Organigram } from "@/components/team-builder/organigram"
import { ProgressSidebar } from "@/components/team-builder/progress-sidebar"

const teamMembersData = [
  {
    id: "pitch",
    human: {
      role: "Sales & Pitch",
      cost: "$120k/year",
      time: "2-4 weeks",
      pros: ["Deep industry relationships", "Emotional intelligence", "Custom presentations"],
      challenges: ["Slow turnaround", "High fixed costs", "Limited availability", "Inconsistent quality"],
    },
    ai: {
      name: "Pitch.ai",
      personality: "Charismatic & Persuasive",
      cost: "$0.02/pitch",
      time: "2 minutes",
      description:
        "Analyzes your idea and generates compelling pitch decks, sales scripts, and investor presentations.",
      pros: ["Instant generation", "Data-driven insights", "Unlimited iterations", "24/7 availability"],
    },
    hybrid: {
      cost: "$18k/year",
      time: "1 hour/day",
      description: "AI generates initial drafts, human refines and customizes for specific audiences.",
    },
  },
  {
    id: "accounts",
    human: {
      role: "Account Manager",
      cost: "$95k/year",
      time: "Ongoing",
      pros: ["Personal touch", "Relationship building", "Conflict resolution"],
      challenges: ["Manual tracking", "Human error", "Limited hours", "Vacation coverage needed"],
    },
    ai: {
      name: "Sync.ai",
      personality: "Organized & Responsive",
      cost: "$0.01/update",
      time: "Real-time",
      description: "Manages client communications, tracks project status, and provides instant updates.",
      pros: ["Instant responses", "Perfect memory", "Never sleeps", "Scales infinitely"],
    },
    hybrid: {
      cost: "$14k/year",
      time: "30 mins/day",
      description: "AI handles routine updates and scheduling, human manages key relationships and escalations.",
    },
  },
  {
    id: "costing",
    human: {
      role: "Budget Analyst",
      cost: "$85k/year",
      time: "1-2 weeks",
      pros: ["Industry experience", "Negotiation skills", "Risk assessment"],
      challenges: ["Slow estimates", "Manual calculations", "Outdated data", "Human bias"],
    },
    ai: {
      name: "Quote.ai",
      personality: "Precise & Transparent",
      cost: "$0.05/quote",
      time: "5 seconds",
      description: "Analyzes requirements and generates accurate cost estimates with breakdown and timeline.",
      pros: ["Lightning fast", "Real-time pricing", "Historical data analysis", "Zero bias"],
    },
    hybrid: {
      cost: "$13k/year",
      time: "1 hour/week",
      description: "AI provides initial estimates, human reviews and negotiates.",
    },
  },
  {
    id: "requirements",
    human: {
      role: "Business Analyst",
      cost: "$110k/year",
      time: "2-3 weeks",
      pros: ["Stakeholder interviews", "Context understanding", "Documentation"],
      challenges: ["Lengthy discovery", "Misinterpretation risk", "Manual documentation", "Slow iterations"],
    },
    ai: {
      name: "Spec.ai",
      personality: "Detail-Oriented & Clarifying",
      cost: "$0.03/spec",
      time: "10 minutes",
      description: "Converts ideas into technical specifications, user stories, and acceptance criteria.",
      pros: ["Instant specs", "No ambiguity", "Rapid iterations", "Always thorough"],
    },
    hybrid: {
      cost: "$16k/year",
      time: "1-2 hours/day",
      description: "AI generates initial requirements, human conducts stakeholder interviews and refines.",
    },
  },
  {
    id: "design",
    human: {
      role: "UI/UX Designer",
      cost: "$105k/year",
      time: "3-4 weeks",
      pros: ["Creative vision", "User empathy", "Brand development"],
      challenges: ["Long design cycles", "Subjective feedback loops", "Limited output", "Revisions take time"],
    },
    ai: {
      name: "Canvas.ai",
      personality: "Creative & Visionary",
      cost: "$0.08/design",
      time: "15 minutes",
      description: "Creates pixel-perfect designs, prototypes, and complete design systems.",
      pros: ["Infinite variations", "Instant prototypes", "Perfect consistency", "Data-backed decisions"],
    },
    hybrid: {
      cost: "$15k/year",
      time: "2 hours/day",
      description: "AI generates design options, human curates, refines, and ensures brand consistency.",
    },
  },
  {
    id: "pm",
    human: {
      role: "Project Manager",
      cost: "$115k/year",
      time: "Full lifecycle",
      pros: ["Leadership skills", "Team coordination", "Risk management"],
      challenges: ["Communication overhead", "Status meeting fatigue", "Single point of failure", "Limited bandwidth"],
    },
    ai: {
      name: "Flow.ai",
      personality: "Strategic & Adaptive",
      cost: "$0.02/day",
      time: "24/7",
      description: "Orchestrates entire project, manages timeline, and coordinates all AI team members.",
      pros: ["Real-time coordination", "Never drops balls", "Instant reports", "Predictive analytics"],
    },
    hybrid: {
      cost: "$17k/year",
      time: "1 hour/day",
      description: "AI manages tasks and deadlines, human provides strategic direction and client communication.",
    },
  },
  {
    id: "frontend",
    human: {
      role: "Frontend Developer",
      cost: "$125k/year",
      time: "4-8 weeks",
      pros: ["Creative problem-solving", "Framework expertise", "Performance optimization"],
      challenges: ["Slow development", "Code review delays", "Limited hours", "Context switching"],
    },
    ai: {
      name: "Render.ai",
      personality: "Meticulous & Fast",
      cost: "$0.15/component",
      time: "Minutes",
      description: "Builds responsive, accessible interfaces with modern frameworks and best practices.",
      pros: ["Instant components", "Perfect accessibility", "Zero bugs", "Best practices built-in"],
    },
    hybrid: {
      cost: "$18k/year",
      time: "2 hours/day",
      description: "AI generates UI components, human integrates, customizes, and optimizes.",
    },
  },
  {
    id: "backend",
    human: {
      role: "Backend Developer",
      cost: "$130k/year",
      time: "4-8 weeks",
      pros: ["Architecture design", "Security expertise", "Database optimization"],
      challenges: ["Long build times", "Integration complexities", "Deployment delays", "Limited availability"],
    },
    ai: {
      name: "Core.ai",
      personality: "Robust & Scalable",
      cost: "$0.20/endpoint",
      time: "Minutes",
      description: "Creates APIs, databases, authentication, and serverless infrastructure.",
      pros: ["Instant APIs", "Auto-scaling", "Security by default", "Zero downtime"],
    },
    hybrid: {
      cost: "$20k/year",
      time: "1.5 hours/day",
      description:
        "AI manages automated pipelines and scaling, human handles complex configurations and incident response.",
    },
  },
  {
    id: "qa",
    human: {
      role: "QA Engineer",
      cost: "$95k/year",
      time: "2-3 weeks",
      pros: ["Creative test scenarios", "User perspective", "Bug hunting"],
      challenges: ["Manual testing", "Regression bottlenecks", "Test coverage gaps", "Tedious work"],
    },
    ai: {
      name: "Test.ai",
      personality: "Thorough & Relentless",
      cost: "$0.05/test suite",
      time: "Seconds",
      description: "Runs comprehensive tests, catches bugs, and ensures quality across all features.",
      pros: ["Exhaustive coverage", "Instant execution", "Never misses", "Self-healing tests"],
    },
    hybrid: {
      cost: "$14k/year",
      time: "1 hour/day",
      description: "AI performs automated testing, human designs test strategies and investigates complex bugs.",
    },
  },
  {
    id: "devops",
    human: {
      role: "DevOps Engineer",
      cost: "$135k/year",
      time: "1-2 weeks",
      pros: ["Infrastructure expertise", "Monitoring setup", "Incident response"],
      challenges: ["Complex pipelines", "Manual deployments", "Alert fatigue", "On-call burden"],
    },
    ai: {
      name: "Deploy.ai",
      personality: "Reliable & Efficient",
      cost: "$0.10/deployment",
      time: "Instant",
      description: "Handles CI/CD, monitoring, scaling, and infrastructure management.",
      pros: ["Zero-touch deployments", "Predictive scaling", "Auto-healing", "Perfect logs"],
    },
    hybrid: {
      cost: "$20k/year",
      time: "1.5 hours/day",
      description:
        "AI manages automated pipelines and scaling, human handles complex configurations and incident response.",
    },
  },
]

export default function TeamBuilderPage() {
  const [currentIndex, setCurrentIndex] = useState(-1)
  const [isPlaying, setIsPlaying] = useState(false)
  const [showSummary, setShowSummary] = useState(false)
  const [hoveredCard, setHoveredCard] = useState<"human" | "ai" | "hybrid" | null>(null)
  const [selections, setSelections] = useState<Selection[]>([])
  const [teamMode, setTeamMode] = useState<TeamMode>("2-part")

  const startAnimation = (mode: TeamMode) => {
    setTeamMode(mode)
    setIsPlaying(true)
    setCurrentIndex(0)
    setShowSummary(false)
    setSelections([])
  }

  const handleStepClick = (index: number) => {
    setSelections(selections.slice(0, index))
    setCurrentIndex(index)
    setShowSummary(false)
  }

  const handleSelection = (type: "human" | "ai" | "hybrid") => {
    const currentMember = teamMembersData[currentIndex]
    const selection: Selection = {
      roleId: currentMember.id,
      type,
      role: type === "human" ? currentMember.human.role : type === "ai" ? currentMember.ai.name : "Hybrid Mode",
      cost:
        type === "human"
          ? currentMember.human.cost
          : type === "ai"
            ? currentMember.ai.cost
            : currentMember.hybrid?.cost || "",
      time:
        type === "human"
          ? currentMember.human.time
          : type === "ai"
            ? currentMember.ai.time
            : currentMember.hybrid?.time || "",
      name: type === "ai" ? currentMember.ai.name : undefined,
    }

    setSelections([...selections, selection])

    if (currentIndex < teamMembersData.length - 1) {
      setCurrentIndex(currentIndex + 1)
    } else {
      setShowSummary(true)
    }
  }

  const calculateTotals = () => {
    const humanSelections = selections.filter((s) => s.type === "human")
    const aiSelections = selections.filter((s) => s.type === "ai")
    const hybridSelections = selections.filter((s) => s.type === "hybrid")

    const humanCostTotal = humanSelections.reduce((sum, s) => {
      const costStr = s.cost.replace(/\$|k\/year|,/g, "")
      return sum + Number.parseInt(costStr) * 1000
    }, 0)

    const aiCostTotal = aiSelections.reduce((sum, s) => {
      const costStr = s.cost.replace(/\$|\/.*$/g, "")
      return sum + Number.parseFloat(costStr)
    }, 0)

    const hybridCostTotal = hybridSelections.reduce((sum, s) => {
      const costStr = s.cost.replace(/\$|k\/year|,/g, "")
      return sum + Number.parseInt(costStr) * 1000
    }, 0)

    return {
      humanCount: humanSelections.length,
      aiCount: aiSelections.length,
      hybridCount: hybridSelections.length,
      humanCost: humanCostTotal,
      aiCost: aiCostTotal,
      hybridCost: hybridCostTotal,
      totalSavings: humanCostTotal - aiCostTotal - hybridCostTotal,
    }
  }

  const totals = calculateTotals()

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-background pt-16">
        <header className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
          <div className="container mx-auto px-6 py-4 flex items-center justify-between">
            <Link href="/" className="font-mono text-xl font-bold tracking-tight">
              <span className="text-foreground">Idea</span>
              <span className="text-accent">i</span>
            </Link>
            <Link href="/">
              <Button variant="ghost" size="sm">
                Back to Home
              </Button>
            </Link>
          </div>
        </header>

        <main className="pt-24 pb-20">
          {!isPlaying ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="container mx-auto px-6 max-w-5xl"
            >
              <div className="text-center space-y-8">
                <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-accent/10 border border-accent/20">
                  <Bot className="w-5 h-5 text-accent" />
                  <span className="font-mono text-sm text-accent">The Future of Software Development</span>
                </div>

                <h1 className="text-6xl md:text-7xl font-bold tracking-tight text-balance">
                  Replace Your Entire Team
                  <br />
                  <span className="text-accent">With AI Agents</span>
                </h1>

                <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
                  Build your perfect team. Choose between traditional humans, AI agents, or hybrid approaches for each
                  role.
                </p>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
                  <Button
                    size="lg"
                    onClick={() => startAnimation("2-part")}
                    className="text-lg px-8 py-6 rounded-full min-w-64"
                  >
                    2-Part Mode
                    <span className="ml-2 text-sm opacity-80">(Human vs AI)</span>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={() => startAnimation("3-part")}
                    className="text-lg px-8 py-6 rounded-full min-w-64"
                  >
                    3-Part Mode
                    <span className="ml-2 text-sm opacity-80">(+ Hybrid)</span>
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-16">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="p-6 rounded-2xl border border-border bg-card"
                  >
                    <Users className="w-8 h-8 text-accent mb-4" />
                    <div className="text-3xl font-bold mb-2">{teamMembersData.length}</div>
                    <div className="text-sm text-muted-foreground">Roles to Build</div>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="p-6 rounded-2xl border border-border bg-card"
                  >
                    <DollarSign className="w-8 h-8 text-accent mb-4" />
                    <div className="text-3xl font-bold mb-2">99.9%</div>
                    <div className="text-sm text-muted-foreground">Potential Savings</div>
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="p-6 rounded-2xl border border-border bg-card"
                  >
                    <Zap className="w-8 h-8 text-accent mb-4" />
                    <div className="text-3xl font-bold mb-2">100x</div>
                    <div className="text-sm text-muted-foreground">Faster Delivery</div>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          ) : showSummary ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="container mx-auto px-6 max-w-6xl">
              <div className="space-y-12">
                <div className="text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", duration: 0.6 }}
                    className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-accent/20 border border-accent mb-8"
                  >
                    <Bot className="w-6 h-6 text-accent" />
                    <span className="font-mono text-lg font-bold text-accent">Your Team is Ready</span>
                  </motion.div>
                </div>

                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-center mb-8">Your Team Members</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {selections.map((selection, index) => {
                      const member = teamMembersData.find((m) => m.id === selection.roleId)
                      if (!member) return null

                      return (
                        <motion.div
                          key={selection.roleId}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className={`p-6 rounded-2xl border ${
                            selection.type === "human"
                              ? "bg-zinc-900/50 border-zinc-700"
                              : selection.type === "hybrid"
                                ? "bg-purple-900/20 border-purple-500/30"
                                : "bg-accent/5 border-accent/30"
                          }`}
                        >
                          <div className="flex items-start justify-between mb-4">
                            <div
                              className={`w-12 h-12 rounded-full flex items-center justify-center ${
                                selection.type === "human"
                                  ? "bg-zinc-700"
                                  : selection.type === "hybrid"
                                    ? "bg-purple-500/30"
                                    : "bg-accent/20"
                              }`}
                            >
                              {selection.type === "human" ? (
                                <Users className="w-6 h-6 text-zinc-300" />
                              ) : selection.type === "hybrid" ? (
                                <Users className="w-6 h-6 text-purple-300" />
                              ) : (
                                <Bot className="w-6 h-6 text-accent" />
                              )}
                            </div>
                            <div
                              className={`px-3 py-1 rounded-full text-xs font-mono ${
                                selection.type === "human"
                                  ? "bg-zinc-700 text-zinc-300"
                                  : selection.type === "hybrid"
                                    ? "bg-purple-500/30 text-purple-300"
                                    : "bg-accent/20 text-accent"
                              }`}
                            >
                              {selection.type === "human" ? "HUMAN" : selection.type === "hybrid" ? "HYBRID" : "AI"}
                            </div>
                          </div>

                          <h3 className="text-lg font-bold mb-1">
                            {selection.type === "ai" ? selection.name : member.human.role}
                          </h3>
                          <p className="text-sm text-muted-foreground mb-4">{member.human.role}</p>

                          {selection.type === "ai" && (
                            <p className="text-xs text-muted-foreground/80 mb-4 italic">{member.ai.personality}</p>
                          )}

                          <div className="space-y-2 pt-4 border-t border-border/50">
                            <div className="flex justify-between items-center text-sm">
                              <span className="text-muted-foreground">Cost</span>
                              <span className="font-semibold">{selection.cost}</span>
                            </div>
                            <div className="flex justify-between items-center text-sm">
                              <span className="text-muted-foreground">Time</span>
                              <span className="font-semibold">{selection.time}</span>
                            </div>
                          </div>
                        </motion.div>
                      )
                    })}
                  </div>
                </div>

                <BusinessCard selections={selections} />

                <Organigram selections={selections} />

                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
                  <Link href="/">
                    <Button size="lg" className="text-lg px-8 py-6 rounded-full">
                      Get Started with Ideai
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </Link>
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={() => {
                      setIsPlaying(false)
                      setCurrentIndex(-1)
                      setShowSummary(false)
                    }}
                    className="text-lg px-8 py-6 rounded-full"
                  >
                    Build Another Team
                  </Button>
                </div>
              </div>
            </motion.div>
          ) : (
            <div className="flex min-h-[calc(100vh-6rem)]">
              <ProgressSidebar
                currentIndex={currentIndex}
                selections={selections}
                teamMembers={teamMembersData}
                onStepClick={handleStepClick}
              />

              <div className="flex-1 px-6">
                <div className="max-w-7xl mx-auto">
                  <div className="mb-12 text-center">
                    <div className="inline-flex items-center gap-2 text-sm font-mono text-muted-foreground mb-2">
                      <span className="text-accent font-bold">{currentIndex + 1}</span>
                      <span>/</span>
                      <span>{teamMembersData.length}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mb-4">
                      Mode: {teamMode === "2-part" ? "Human vs AI" : "Human vs Hybrid vs AI"}
                    </p>
                    <div className="h-1 bg-border rounded-full max-w-md mx-auto">
                      <motion.div
                        className="h-full bg-accent rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${((currentIndex + 1) / teamMembersData.length) * 100}%` }}
                        transition={{ duration: 0.3 }}
                      />
                    </div>
                  </div>

                  <AnimatePresence mode="wait">
                    {currentIndex >= 0 && (
                      <motion.div
                        key={currentIndex}
                        initial={{ opacity: 0, x: 100 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -100 }}
                        transition={{ duration: 0.5 }}
                        className="space-y-8"
                      >
                        {teamMode === "2-part" ? (
                          <div className="grid md:grid-cols-2 gap-8 items-stretch">
                            <RoleCardHuman
                              member={teamMembersData[currentIndex]}
                              isHovered={hoveredCard === "human"}
                              onHover={() => setHoveredCard("human")}
                              onLeave={() => setHoveredCard(null)}
                              onSelect={() => handleSelection("human")}
                            />
                            <RoleCardAi
                              member={teamMembersData[currentIndex]}
                              isHovered={hoveredCard === "ai"}
                              onHover={() => setHoveredCard("ai")}
                              onLeave={() => setHoveredCard(null)}
                              onSelect={() => handleSelection("ai")}
                            />
                          </div>
                        ) : (
                          <div className="grid md:grid-cols-3 gap-6 items-stretch">
                            <RoleCardHuman
                              member={teamMembersData[currentIndex]}
                              isHovered={hoveredCard === "human"}
                              onHover={() => setHoveredCard("human")}
                              onLeave={() => setHoveredCard(null)}
                              onSelect={() => handleSelection("human")}
                            />
                            <RoleCardHybrid
                              member={teamMembersData[currentIndex]}
                              isHovered={hoveredCard === "hybrid"}
                              onHover={() => setHoveredCard("hybrid")}
                              onLeave={() => setHoveredCard(null)}
                              onSelect={() => handleSelection("hybrid")}
                            />
                            <RoleCardAi
                              member={teamMembersData[currentIndex]}
                              isHovered={hoveredCard === "ai"}
                              onHover={() => setHoveredCard("ai")}
                              onLeave={() => setHoveredCard(null)}
                              onSelect={() => handleSelection("ai")}
                            />
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </>
  )
}
