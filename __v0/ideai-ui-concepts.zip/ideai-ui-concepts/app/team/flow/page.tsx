"use client"

import { useState, useCallback, useMemo } from "react"
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  addEdge,
  useNodesState,
  useEdgesState,
  type Connection,
  type Edge,
  type Node,
  Panel,
} from "@xyflow/react"
import "@xyflow/react/dist/style.css"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Plus, Users, Bot, UserCog, Check } from "lucide-react"
import { Navigation } from "@/components/navigation"

type PersonType = "human" | "ai" | "hybrid"

interface TeamNodeData {
  label: string
  role: string
  type: PersonType
  cost: number
  time: string
}

const roleOptions = [
  { role: "Sales & Pitch", cost: 120000, time: "2-4 weeks", aiCost: 50, aiTime: "1 hour" },
  { role: "Project Manager", cost: 140000, time: "Full project", aiCost: 100, aiTime: "Ongoing" },
  { role: "Business Analyst", cost: 110000, time: "2-3 weeks", aiCost: 25, aiTime: "2 hours" },
  { role: "UI/UX Designer", cost: 105000, time: "3-4 weeks", aiCost: 75, aiTime: "1 day" },
  { role: "Frontend Dev", cost: 130000, time: "4-8 weeks", aiCost: 150, aiTime: "2 days" },
  { role: "Backend Dev", cost: 135000, time: "4-8 weeks", aiCost: 200, aiTime: "3 days" },
  { role: "DevOps Engineer", cost: 145000, time: "2-3 weeks", aiCost: 50, aiTime: "1 day" },
  { role: "QA Tester", cost: 95000, time: "2-4 weeks", aiCost: 30, aiTime: "1 day" },
]

const nodeColor = (type: PersonType) => {
  if (type === "human") return "#52525b"
  if (type === "ai") return "#3b82f6"
  return "#8b5cf6"
}

function TeamNode({ data }: { data: TeamNodeData }) {
  const Icon = data.type === "human" ? Users : data.type === "ai" ? Bot : UserCog

  return (
    <Card className="min-w-[200px] p-3 border-2" style={{ borderColor: nodeColor(data.type) }}>
      <div className="flex items-start gap-2">
        <Icon className="w-5 h-5 mt-0.5" style={{ color: nodeColor(data.type) }} />
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-sm truncate">{data.label}</div>
          <div className="text-xs text-muted-foreground">{data.role}</div>
          <div className="text-xs text-muted-foreground mt-1">${data.cost.toLocaleString()}</div>
          <div className="text-xs text-muted-foreground">{data.time}</div>
        </div>
      </div>
    </Card>
  )
}

function GanttNode({ data }: { data: any }) {
  return (
    <Card className="min-w-[180px] p-2 bg-gradient-to-r from-blue-500/20 to-purple-500/20">
      <div className="text-xs font-semibold">{data.label}</div>
      <div className="text-[10px] text-muted-foreground">{data.duration}</div>
    </Card>
  )
}

function ArchitectureNode({ data }: { data: any }) {
  return (
    <Card className="min-w-[150px] p-3 border border-blue-500/50">
      <div className="text-sm font-semibold text-center">{data.label}</div>
      {data.tech && <div className="text-[10px] text-muted-foreground text-center mt-1">{data.tech}</div>}
    </Card>
  )
}

const nodeTypes = {
  team: TeamNode,
  gantt: GanttNode,
  architecture: ArchitectureNode,
}

const initialOrgNodes: Node[] = [
  {
    id: "1",
    type: "team",
    position: { x: 250, y: 0 },
    data: { label: "CEO", role: "Leadership", type: "human", cost: 0, time: "Oversight" },
  },
]

const initialGanttNodes: Node[] = [
  { id: "g1", type: "gantt", position: { x: 0, y: 0 }, data: { label: "Discovery", duration: "Week 1-2" } },
  { id: "g2", type: "gantt", position: { x: 200, y: 0 }, data: { label: "Design", duration: "Week 3-5" } },
  { id: "g3", type: "gantt", position: { x: 400, y: 0 }, data: { label: "Development", duration: "Week 6-14" } },
  { id: "g4", type: "gantt", position: { x: 600, y: 0 }, data: { label: "Testing", duration: "Week 15-17" } },
  { id: "g5", type: "gantt", position: { x: 800, y: 0 }, data: { label: "Deployment", duration: "Week 18" } },
]

const initialGanttEdges: Edge[] = [
  { id: "ge1-2", source: "g1", target: "g2", animated: true },
  { id: "ge2-3", source: "g2", target: "g3", animated: true },
  { id: "ge3-4", source: "g3", target: "g4", animated: true },
  { id: "ge4-5", source: "g4", target: "g5", animated: true },
]

const initialArchNodes: Node[] = [
  { id: "a1", type: "architecture", position: { x: 250, y: 0 }, data: { label: "Frontend", tech: "React/Next.js" } },
  { id: "a2", type: "architecture", position: { x: 250, y: 150 }, data: { label: "API Layer", tech: "REST/GraphQL" } },
  { id: "a3", type: "architecture", position: { x: 100, y: 300 }, data: { label: "Database", tech: "PostgreSQL" } },
  { id: "a4", type: "architecture", position: { x: 400, y: 300 }, data: { label: "Auth Service", tech: "OAuth/JWT" } },
  {
    id: "a5",
    type: "architecture",
    position: { x: 250, y: 450 },
    data: { label: "Cloud Hosting", tech: "AWS/Vercel" },
  },
]

const initialArchEdges: Edge[] = [
  { id: "ae1-2", source: "a1", target: "a2" },
  { id: "ae2-3", source: "a2", target: "a3" },
  { id: "ae2-4", source: "a2", target: "a4" },
  { id: "ae3-5", source: "a3", target: "a5" },
  { id: "ae4-5", source: "a4", target: "a5" },
]

export default function FlowBuilderPage() {
  const [showBuilder, setShowBuilder] = useState(true)
  const [currentStep, setCurrentStep] = useState(0)
  const [selections, setSelections] = useState<Array<{ role: string; type: PersonType; cost: number; time: string }>>(
    [],
  )

  const [activeTab, setActiveTab] = useState("org")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedRole, setSelectedRole] = useState(roleOptions[0])
  const [selectedType, setSelectedType] = useState<PersonType>("ai")

  const [orgNodes, setOrgNodes, onOrgNodesChange] = useNodesState(initialOrgNodes)
  const [orgEdges, setOrgEdges, onOrgEdgesChange] = useEdgesState([])

  const [ganttNodes, setGanttNodes, onGanttNodesChange] = useNodesState(initialGanttNodes)
  const [ganttEdges, setGanttEdges, onGanttEdgesChange] = useEdgesState(initialGanttEdges)

  const [archNodes, setArchNodes, onArchNodesChange] = useNodesState(initialArchNodes)
  const [archEdges, setArchEdges, onArchEdgesChange] = useEdgesState(initialArchEdges)

  const onOrgConnect = useCallback((params: Connection) => setOrgEdges((eds) => addEdge(params, eds)), [setOrgEdges])
  const onGanttConnect = useCallback(
    (params: Connection) => setGanttEdges((eds) => addEdge(params, eds)),
    [setGanttEdges],
  )
  const onArchConnect = useCallback((params: Connection) => setArchEdges((eds) => addEdge(params, eds)), [setArchEdges])

  const addTeamMember = () => {
    const newNode: Node = {
      id: `node-${Date.now()}`,
      type: "team",
      position: { x: Math.random() * 400, y: Math.random() * 300 + 100 },
      data: {
        label: selectedRole.role,
        role: selectedRole.role,
        type: selectedType,
        cost:
          selectedType === "human"
            ? selectedRole.cost
            : selectedType === "ai"
              ? selectedRole.aiCost
              : Math.round((selectedRole.cost + selectedRole.aiCost) / 2),
        time: selectedType === "human" ? selectedRole.time : selectedRole.aiTime,
      },
    }
    setOrgNodes((nds) => [...nds, newNode])
    setIsAddDialogOpen(false)
  }

  const totalCost = useMemo(() => {
    return orgNodes.reduce((sum, node) => {
      if (node.type === "team" && node.data.cost) {
        return sum + node.data.cost
      }
      return sum
    }, 0)
  }, [orgNodes])

  const handleSelectType = (type: PersonType) => {
    const role = roleOptions[currentStep]
    const cost = type === "human" ? role.cost : type === "ai" ? role.aiCost : Math.round((role.cost + role.aiCost) / 2)
    const time = type === "human" ? role.time : role.aiTime

    setSelections([...selections, { role: role.role, type, cost, time }])

    const newNode: Node = {
      id: `node-${Date.now()}`,
      type: "team",
      position: { x: 100 + currentStep * 150, y: 100 + Math.floor(currentStep / 3) * 150 },
      data: {
        label: role.role,
        role: role.role,
        type,
        cost,
        time,
      },
    }
    setOrgNodes((nds) => [...nds, newNode])

    if (currentStep < roleOptions.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      setShowBuilder(false)
    }
  }

  const builderTotalCost = useMemo(() => {
    return selections.reduce((sum, s) => sum + s.cost, 0)
  }, [selections])

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-background pt-16">
        {showBuilder ? (
          <div className="w-full max-w-6xl">
            <div className="mb-8">
              <div className="flex justify-between text-sm text-muted-foreground mb-2">
                <span>
                  Step {currentStep + 1} of {roleOptions.length}
                </span>
                <span>{Math.round(((currentStep + 1) / roleOptions.length) * 100)}% Complete</span>
              </div>
              <div className="h-1 bg-zinc-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all"
                  style={{ width: `${((currentStep + 1) / roleOptions.length) * 100}%` }}
                />
              </div>
            </div>

            <div className="mb-6">
              <h2 className="text-3xl font-bold mb-2">{roleOptions[currentStep].role}</h2>
              <p className="text-muted-foreground">Choose how you want to fill this role</p>
            </div>

            <div className="grid grid-cols-3 gap-6 mb-8">
              <Card
                className="p-6 cursor-pointer transition-all hover:scale-105 hover:border-zinc-600 border-2 bg-gradient-to-br from-zinc-900 to-zinc-800"
                onClick={() => handleSelectType("human")}
              >
                <div className="flex flex-col h-full">
                  <Users className="w-12 h-12 mb-4 text-zinc-400" />
                  <h3 className="text-xl font-semibold mb-2">Human</h3>
                  <p className="text-sm text-muted-foreground mb-4 flex-1">Traditional hire with full expertise</p>
                  <div className="space-y-2 border-t border-zinc-700 pt-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Cost:</span>
                      <span className="font-semibold">${(roleOptions[currentStep].cost / 1000).toFixed(0)}k/year</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Time:</span>
                      <span className="font-semibold">{roleOptions[currentStep].time}</span>
                    </div>
                  </div>
                </div>
              </Card>

              <Card
                className="p-6 cursor-pointer transition-all hover:scale-105 hover:border-purple-500 border-2 bg-gradient-to-br from-purple-950/40 to-zinc-900"
                onClick={() => handleSelectType("hybrid")}
              >
                <div className="flex flex-col h-full">
                  <UserCog className="w-12 h-12 mb-4 text-purple-400" />
                  <h3 className="text-xl font-semibold mb-2">Hybrid</h3>
                  <p className="text-sm text-muted-foreground mb-4 flex-1">AI with 1hr/day human oversight</p>
                  <div className="space-y-2 border-t border-purple-900/50 pt-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Cost:</span>
                      <span className="font-semibold text-purple-400">
                        $
                        {Math.round(
                          (roleOptions[currentStep].cost + roleOptions[currentStep].aiCost) / 2,
                        ).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Time:</span>
                      <span className="font-semibold text-purple-400">{roleOptions[currentStep].aiTime}</span>
                    </div>
                  </div>
                </div>
              </Card>

              <Card
                className="p-6 cursor-pointer transition-all hover:scale-105 hover:border-blue-500 border-2 bg-gradient-to-br from-blue-950/40 to-zinc-900"
                onClick={() => handleSelectType("ai")}
              >
                <div className="flex flex-col h-full">
                  <Bot className="w-12 h-12 mb-4 text-blue-400" />
                  <h3 className="text-xl font-semibold mb-2">AI Agent</h3>
                  <p className="text-sm text-muted-foreground mb-4 flex-1">Fully automated AI solution</p>
                  <div className="space-y-2 border-t border-blue-900/50 pt-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Cost:</span>
                      <span className="font-semibold text-blue-400">${roleOptions[currentStep].aiCost}/use</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Time:</span>
                      <span className="font-semibold text-blue-400">{roleOptions[currentStep].aiTime}</span>
                    </div>
                  </div>
                </div>
              </Card>
            </div>

            {selections.length > 0 && (
              <Card className="p-6 bg-zinc-950 border-zinc-800">
                <h3 className="text-lg font-semibold mb-4">Your Team So Far</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                  {selections.map((sel, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm">
                      <Check className="w-4 h-4 text-green-500" />
                      <span className="truncate">{sel.role}</span>
                      <span
                        className="text-xs px-1.5 py-0.5 rounded"
                        style={{
                          backgroundColor: `${nodeColor(sel.type)}20`,
                          color: nodeColor(sel.type),
                        }}
                      >
                        {sel.type}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="flex justify-between items-center border-t border-zinc-800 pt-4">
                  <span className="text-muted-foreground">Current Total:</span>
                  <span className="text-2xl font-bold text-blue-500">${builderTotalCost.toLocaleString()}</span>
                </div>
              </Card>
            )}
          </div>
        ) : (
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-4xl font-bold mb-2">Your Complete Project Visualization</h1>
                <p className="text-muted-foreground">Team structure, timeline, and architecture all in one view</p>
              </div>
              <Button variant="outline" onClick={() => setShowBuilder(true)}>
                Rebuild Team
              </Button>
            </div>

            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold mb-3">Team Organization</h2>
                <div className="h-[400px]">
                  <ReactFlow
                    nodes={orgNodes}
                    edges={orgEdges}
                    onNodesChange={onOrgNodesChange}
                    onEdgesChange={onOrgEdgesChange}
                    onConnect={onOrgConnect}
                    nodeTypes={nodeTypes}
                    fitView
                    className="bg-zinc-950 rounded-lg border border-zinc-800"
                  >
                    <Background />
                    <Controls />
                    <MiniMap />
                    <Panel position="top-right">
                      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                        <DialogTrigger asChild>
                          <Button className="gap-2">
                            <Plus className="w-4 h-4" />
                            Add Member
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Add Team Member</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <label className="text-sm font-medium mb-2 block">Role</label>
                              <select
                                className="w-full p-2 rounded bg-zinc-900 border border-zinc-800"
                                value={selectedRole.role}
                                onChange={(e) =>
                                  setSelectedRole(roleOptions.find((r) => r.role === e.target.value) || roleOptions[0])
                                }
                              >
                                {roleOptions.map((role) => (
                                  <option key={role.role} value={role.role}>
                                    {role.role}
                                  </option>
                                ))}
                              </select>
                            </div>

                            <div>
                              <label className="text-sm font-medium mb-2 block">Type</label>
                              <div className="grid grid-cols-3 gap-2">
                                {(["human", "ai", "hybrid"] as PersonType[]).map((type) => (
                                  <Button
                                    key={type}
                                    variant={selectedType === type ? "default" : "outline"}
                                    onClick={() => setSelectedType(type)}
                                    className="capitalize"
                                  >
                                    {type}
                                  </Button>
                                ))}
                              </div>
                            </div>

                            <div className="p-3 rounded bg-zinc-900 text-sm">
                              <div className="flex justify-between mb-1">
                                <span className="text-muted-foreground">Cost:</span>
                                <span className="font-semibold">
                                  $
                                  {selectedType === "human"
                                    ? selectedRole.cost.toLocaleString()
                                    : selectedType === "ai"
                                      ? selectedRole.aiCost
                                      : Math.round((selectedRole.cost + selectedRole.aiCost) / 2).toLocaleString()}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-muted-foreground">Time:</span>
                                <span className="font-semibold">
                                  {selectedType === "human" ? selectedRole.time : selectedRole.aiTime}
                                </span>
                              </div>
                            </div>

                            <Button onClick={addTeamMember} className="w-full">
                              Add to Chart
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </Panel>
                  </ReactFlow>
                </div>
              </div>

              <div>
                <h2 className="text-2xl font-bold mb-3">Project Timeline</h2>
                <div className="h-[300px]">
                  <ReactFlow
                    nodes={ganttNodes}
                    edges={ganttEdges}
                    onNodesChange={onGanttNodesChange}
                    onEdgesChange={onGanttEdgesChange}
                    onConnect={onGanttConnect}
                    nodeTypes={nodeTypes}
                    fitView
                    className="bg-zinc-950 rounded-lg border border-zinc-800"
                  >
                    <Background />
                    <Controls />
                    <MiniMap />
                  </ReactFlow>
                </div>
              </div>

              <div>
                <h2 className="text-2xl font-bold mb-3">SaaS Architecture</h2>
                <div className="h-[500px]">
                  <ReactFlow
                    nodes={archNodes}
                    edges={archEdges}
                    onNodesChange={onArchNodesChange}
                    onEdgesChange={onArchEdgesChange}
                    onConnect={onArchConnect}
                    nodeTypes={nodeTypes}
                    fitView
                    className="bg-zinc-950 rounded-lg border border-zinc-800"
                  >
                    <Background />
                    <Controls />
                    <MiniMap />
                  </ReactFlow>
                </div>
              </div>
            </div>

            <Card className="mt-6 p-6 bg-zinc-950 border-zinc-800">
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <h3 className="font-semibold mb-2">Team Size</h3>
                  <p className="text-3xl font-bold text-blue-500">{orgNodes.length - 1}</p>
                  <p className="text-sm text-muted-foreground">Active members</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Timeline</h3>
                  <p className="text-3xl font-bold text-purple-500">18 weeks</p>
                  <p className="text-sm text-muted-foreground">Estimated delivery</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Total Cost</h3>
                  <p className="text-3xl font-bold text-green-500">${totalCost.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">Annual budget</p>
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>
    </>
  )
}
