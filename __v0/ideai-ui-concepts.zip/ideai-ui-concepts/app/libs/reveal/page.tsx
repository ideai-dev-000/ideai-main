"use client"

import { useEffect, useRef } from "react"
import { Navigation } from "@/components/navigation"
import Reveal from "reveal.js"
import "reveal.js/dist/reveal.css"
import "reveal.js/dist/theme/black.css"

export default function RevealPage() {
  const deckRef = useRef<HTMLDivElement>(null)
  const revealInstanceRef = useRef<Reveal.Api | null>(null)

  useEffect(() => {
    if (deckRef.current && !revealInstanceRef.current) {
      revealInstanceRef.current = new Reveal(deckRef.current, {
        embedded: true,
        width: "100%",
        height: "100%",
        margin: 0.1,
        minScale: 0.2,
        maxScale: 2.0,
        controls: true,
        progress: true,
        center: true,
        hash: true,
        transition: "slide",
        backgroundTransition: "fade",
      })
      revealInstanceRef.current.initialize()
    }

    return () => {
      if (revealInstanceRef.current) {
        revealInstanceRef.current.destroy()
        revealInstanceRef.current = null
      }
    }
  }, [])

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-background pt-16">
        <div className="container mx-auto px-6 py-12">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">Reveal.js Demo</h1>
            <p className="text-muted-foreground">
              Professional HTML presentations with slide navigation, transitions, and themes
            </p>
          </div>

          <div className="rounded-lg border border-border overflow-hidden" style={{ height: "calc(100vh - 280px)" }}>
            <div ref={deckRef} className="reveal">
              <div className="slides">
                <section data-background-gradient="linear-gradient(to bottom, #000000, #1a1a2e)">
                  <h1>Ideai Platform</h1>
                  <h3>Turn Ideas into Software with AI</h3>
                  <p className="text-sm opacity-70">Press → to navigate</p>
                </section>

                <section data-background-gradient="linear-gradient(to bottom, #1a1a2e, #16213e)">
                  <h2>What is Ideai?</h2>
                  <ul>
                    <li>IDE + IDEA + AI + IDEAL</li>
                    <li>Full-stack development with AI agents</li>
                    <li>Replace entire development teams</li>
                    <li>Build apps, games, SaaS products</li>
                  </ul>
                </section>

                <section data-background-gradient="linear-gradient(to bottom, #16213e, #0f3460)">
                  <h2>AI Agent Team</h2>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "2rem", marginTop: "2rem" }}>
                    <div>
                      <h4>Sales & Accounts</h4>
                      <p className="text-sm">$0.02/interaction</p>
                    </div>
                    <div>
                      <h4>Project Manager</h4>
                      <p className="text-sm">$0.05/task</p>
                    </div>
                    <div>
                      <h4>Full-Stack Dev</h4>
                      <p className="text-sm">$0.10/feature</p>
                    </div>
                    <div>
                      <h4>QA Engineer</h4>
                      <p className="text-sm">$0.03/test</p>
                    </div>
                  </div>
                </section>

                <section data-background-gradient="linear-gradient(to bottom, #0f3460, #533483)">
                  <h2>Cost Comparison</h2>
                  <table style={{ width: "100%", marginTop: "2rem", fontSize: "0.9em" }}>
                    <thead>
                      <tr>
                        <th>Role</th>
                        <th>Human Team</th>
                        <th>AI Team</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>10-person team</td>
                        <td>$1.2M/year</td>
                        <td>Pay-as-you-go</td>
                      </tr>
                      <tr>
                        <td>Project timeline</td>
                        <td>6-12 months</td>
                        <td>2-4 weeks</td>
                      </tr>
                      <tr>
                        <td>Availability</td>
                        <td>9-5, weekdays</td>
                        <td>24/7/365</td>
                      </tr>
                    </tbody>
                  </table>
                </section>

                <section data-background-gradient="linear-gradient(to bottom, #533483, #000000)">
                  <h2>Get Started</h2>
                  <p>Transform your ideas into reality</p>
                  <button
                    style={{
                      marginTop: "2rem",
                      padding: "1rem 2rem",
                      background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
                      border: "none",
                      borderRadius: "8px",
                      color: "white",
                      fontSize: "1.1rem",
                      cursor: "pointer",
                    }}
                  >
                    Start Building
                  </button>
                </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
