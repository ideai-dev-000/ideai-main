"use client"

import { Suspense, useRef, useState } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Text, Line, Sphere } from "@react-three/drei"
import { Navigation } from "@/components/navigation"
import { Card } from "@/components/ui/card"
import * as THREE from "three"
import { createNoise3D } from "simplex-noise"

interface Node3D {
  id: string
  name: string
  position: [number, number, number]
  children: Node3D[]
  expanded: boolean
  type: string
}

const noise3D = createNoise3D()

function FlowingLine({
  start,
  end,
  progress,
}: { start: [number, number, number]; end: [number, number, number]; progress: number }) {
  const points = []
  for (let i = 0; i <= 20; i++) {
    const t = i / 20
    const x = start[0] + (end[0] - start[0]) * t
    const y = start[1] + (end[1] - start[1]) * t
    const z = start[2] + (end[2] - start[2]) * t
    points.push(new THREE.Vector3(x, y, z))
  }

  const particleRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (particleRef.current) {
      const t = (state.clock.elapsedTime * 0.5) % 1
      const x = start[0] + (end[0] - start[0]) * t
      const y = start[1] + (end[1] - start[1]) * t
      const z = start[2] + (end[2] - start[2]) * t
      particleRef.current.position.set(x, y, z)
    }
  })

  return (
    <>
      <Line points={points} color="#3b82f6" lineWidth={2} opacity={0.6} transparent />
      <mesh ref={particleRef}>
        <sphereGeometry args={[0.1, 16, 16]} />
        <meshStandardMaterial color="#60a5fa" emissive="#3b82f6" emissiveIntensity={2} />
      </mesh>
    </>
  )
}

function Node3DComponent({
  node,
  onExpand,
}: {
  node: Node3D
  onExpand: (id: string) => void
}) {
  const meshRef = useRef<THREE.Mesh>(null)
  const [hovered, setHovered] = useState(false)

  useFrame((state) => {
    if (meshRef.current) {
      const time = state.clock.elapsedTime
      const scale = hovered ? 1.3 : 1 + Math.sin(time * 2 + node.position[0]) * 0.1
      meshRef.current.scale.setScalar(scale)
    }
  })

  const color = node.type === "root" ? "#7c3aed" : node.type === "parent" ? "#3b82f6" : "#10b981"

  return (
    <group position={node.position}>
      <Sphere
        ref={meshRef}
        args={[0.5, 32, 32]}
        onClick={(e) => {
          e.stopPropagation()
          onExpand(node.id)
        }}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={hovered ? 0.5 : 0.2} />
      </Sphere>
      <Text position={[0, -1, 0]} fontSize={0.3} color="white" anchorX="center" anchorY="middle">
        {node.name}
      </Text>
      {node.expanded &&
        node.children.map((child, i) => (
          <group key={child.id}>
            <FlowingLine start={node.position} end={child.position} progress={0} />
            <Node3DComponent node={child} onExpand={onExpand} />
          </group>
        ))}
    </group>
  )
}

function NoiseBackground() {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (meshRef.current) {
      const time = state.clock.elapsedTime * 0.5
      const geometry = meshRef.current.geometry
      const positions = geometry.attributes.position

      for (let i = 0; i < positions.count; i++) {
        const x = positions.getX(i)
        const y = positions.getY(i)
        const z = noise3D(x * 0.5, y * 0.5, time) * 0.5
        positions.setZ(i, z)
      }

      positions.needsUpdate = true
    }
  })

  return (
    <mesh ref={meshRef} position={[0, 0, -10]} rotation={[-Math.PI / 4, 0, 0]}>
      <planeGeometry args={[30, 30, 40, 40]} />
      <meshStandardMaterial color="#1a1a2e" wireframe opacity={0.3} transparent />
    </mesh>
  )
}

export default function Graph3DPage() {
  const [rootNode, setRootNode] = useState<Node3D>({
    id: "root",
    name: "AI Core",
    position: [0, 0, 0],
    children: [],
    expanded: false,
    type: "root",
  })

  const expandNode = (id: string) => {
    const findAndExpand = (node: Node3D): Node3D => {
      if (node.id === id) {
        if (!node.expanded) {
          const childCount = 4
          const radius = 4
          const children: Node3D[] = []

          for (let i = 0; i < childCount; i++) {
            const angle = (i / childCount) * Math.PI * 2
            const x = node.position[0] + Math.cos(angle) * radius
            const y = node.position[1] + Math.sin(angle) * radius
            const z = node.position[2] + (Math.random() - 0.5) * 2

            children.push({
              id: `${id}-child-${i}`,
              name: `Node ${id.split("-").length}-${i}`,
              position: [x, y, z],
              children: [],
              expanded: false,
              type: "parent",
            })
          }

          return { ...node, children, expanded: true }
        }
      }

      return {
        ...node,
        children: node.children.map(findAndExpand),
      }
    }

    setRootNode(findAndExpand(rootNode))
  }

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-background pt-16">
        <div className="container mx-auto px-6 py-12">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2 text-foreground">3D Interactive Graph Network</h1>
            <p className="text-muted-foreground">
              Explore infinite node networks in 3D space with flowing data visualization and Perlin noise backgrounds
            </p>
          </div>

          <Card className="p-6 mb-6">
            <div className="relative w-full h-[700px] bg-black rounded-lg overflow-hidden">
              <Canvas camera={{ position: [0, 0, 15], fov: 60 }}>
                <Suspense fallback={null}>
                  <ambientLight intensity={0.5} />
                  <pointLight position={[10, 10, 10]} intensity={1} />
                  <pointLight position={[-10, -10, -10]} intensity={0.5} color="#3b82f6" />
                  <NoiseBackground />
                  <Node3DComponent node={rootNode} onExpand={expandNode} />
                  <OrbitControls enableDamping dampingFactor={0.05} />
                </Suspense>
              </Canvas>
            </div>
          </Card>

          <div className="grid md:grid-cols-4 gap-4">
            <Card className="p-4">
              <h3 className="font-semibold mb-2 text-foreground">3D Navigation</h3>
              <p className="text-sm text-muted-foreground">Drag to rotate, scroll to zoom, right-click to pan</p>
            </Card>
            <Card className="p-4">
              <h3 className="font-semibold mb-2 text-foreground">Flowing Data</h3>
              <p className="text-sm text-muted-foreground">Particles flow between connected nodes</p>
            </Card>
            <Card className="p-4">
              <h3 className="font-semibold mb-2 text-foreground">Perlin Noise</h3>
              <p className="text-sm text-muted-foreground">Animated background using simplex noise</p>
            </Card>
            <Card className="p-4">
              <h3 className="font-semibold mb-2 text-foreground">Infinite Expansion</h3>
              <p className="text-sm text-muted-foreground">Click nodes to spawn 4 children infinitely</p>
            </Card>
          </div>
        </div>
      </div>
    </>
  )
}
