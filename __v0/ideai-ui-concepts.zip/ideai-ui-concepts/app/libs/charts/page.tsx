"use client"

import { Navigation } from "@/components/navigation"
import { Line, Bar, Doughnut, Radar } from "react-chartjs-2"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  RadialLinearScale,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js"

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  RadialLinearScale,
  Title,
  Tooltip,
  Legend,
  Filler,
)

export default function ChartsPage() {
  const lineData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    datasets: [
      {
        label: "AI Agent Tasks",
        data: [65, 89, 110, 145, 190, 240, 310, 390, 480, 590, 720, 890],
        borderColor: "rgb(99, 102, 241)",
        backgroundColor: "rgba(99, 102, 241, 0.1)",
        tension: 0.4,
        fill: true,
      },
      {
        label: "Human Tasks",
        data: [45, 52, 58, 62, 65, 68, 70, 72, 74, 75, 76, 78],
        borderColor: "rgb(156, 163, 175)",
        backgroundColor: "rgba(156, 163, 175, 0.1)",
        tension: 0.4,
        fill: true,
      },
    ],
  }

  const barData = {
    labels: ["Dev", "Design", "QA", "PM", "DevOps", "Sales"],
    datasets: [
      {
        label: "Human Cost ($k/year)",
        data: [120, 100, 85, 110, 115, 95],
        backgroundColor: "rgba(156, 163, 175, 0.8)",
      },
      {
        label: "AI Cost ($k/year)",
        data: [2.4, 1.8, 1.2, 2.0, 1.5, 0.8],
        backgroundColor: "rgba(99, 102, 241, 0.8)",
      },
    ],
  }

  const doughnutData = {
    labels: ["AI Agents", "Human Oversight", "Infrastructure", "Support"],
    datasets: [
      {
        data: [45, 25, 20, 10],
        backgroundColor: [
          "rgba(99, 102, 241, 0.8)",
          "rgba(139, 92, 246, 0.8)",
          "rgba(168, 85, 247, 0.8)",
          "rgba(192, 132, 252, 0.8)",
        ],
        borderWidth: 0,
      },
    ],
  }

  const radarData = {
    labels: ["Speed", "Quality", "Cost", "Scalability", "Availability", "Consistency"],
    datasets: [
      {
        label: "AI Team",
        data: [95, 92, 98, 100, 100, 98],
        borderColor: "rgb(99, 102, 241)",
        backgroundColor: "rgba(99, 102, 241, 0.2)",
      },
      {
        label: "Human Team",
        data: [60, 85, 45, 65, 55, 70],
        borderColor: "rgb(156, 163, 175)",
        backgroundColor: "rgba(156, 163, 175, 0.2)",
      },
    ],
  }

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: true,
    plugins: {
      legend: {
        labels: {
          color: "hsl(var(--foreground))",
          font: {
            size: 12,
          },
        },
      },
    },
    scales: {
      x: {
        ticks: {
          color: "hsl(var(--muted-foreground))",
        },
        grid: {
          color: "hsl(var(--border))",
        },
      },
      y: {
        ticks: {
          color: "hsl(var(--muted-foreground))",
        },
        grid: {
          color: "hsl(var(--border))",
        },
      },
    },
  }

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-background pt-16">
        <div className="container mx-auto px-6 py-12">
          <div className="mb-12">
            <h1 className="text-4xl font-bold mb-2">Chart.js Demo</h1>
            <p className="text-muted-foreground">Professional data visualizations showing AI vs Human team metrics</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Line Chart */}
            <div className="bg-card border border-border rounded-xl p-6">
              <h3 className="text-xl font-semibold mb-4">Task Completion Trends</h3>
              <div className="h-[300px]">
                <Line data={lineData} options={chartOptions} />
              </div>
            </div>

            {/* Bar Chart */}
            <div className="bg-card border border-border rounded-xl p-6">
              <h3 className="text-xl font-semibold mb-4">Annual Cost Comparison</h3>
              <div className="h-[300px]">
                <Bar data={barData} options={chartOptions} />
              </div>
            </div>

            {/* Doughnut Chart */}
            <div className="bg-card border border-border rounded-xl p-6">
              <h3 className="text-xl font-semibold mb-4">Budget Allocation</h3>
              <div className="h-[300px] flex items-center justify-center">
                <Doughnut
                  data={doughnutData}
                  options={{
                    ...chartOptions,
                    scales: undefined,
                  }}
                />
              </div>
            </div>

            {/* Radar Chart */}
            <div className="bg-card border border-border rounded-xl p-6">
              <h3 className="text-xl font-semibold mb-4">Performance Metrics</h3>
              <div className="h-[300px] flex items-center justify-center">
                <Radar
                  data={radarData}
                  options={{
                    ...chartOptions,
                    scales: {
                      r: {
                        ticks: {
                          color: "hsl(var(--muted-foreground))",
                        },
                        grid: {
                          color: "hsl(var(--border))",
                        },
                        pointLabels: {
                          color: "hsl(var(--foreground))",
                        },
                      },
                    },
                  }}
                />
              </div>
            </div>
          </div>

          <div className="mt-12 bg-card border border-border rounded-xl p-8">
            <h3 className="text-2xl font-semibold mb-4">Key Insights</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-accent mb-2">98%</div>
                <div className="text-sm text-muted-foreground">Cost Reduction</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-accent mb-2">10x</div>
                <div className="text-sm text-muted-foreground">Faster Delivery</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-accent mb-2">24/7</div>
                <div className="text-sm text-muted-foreground">Always Available</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
