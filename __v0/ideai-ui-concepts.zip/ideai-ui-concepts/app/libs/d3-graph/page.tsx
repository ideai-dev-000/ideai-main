"use client"

import { useEffect, useRef, useState } from "react"
import { Navigation } from "@/components/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import * as d3 from "d3"
import { Plus, Minus, RotateCcw } from "lucide-react"

interface GraphNode extends d3.SimulationNodeDatum {
  id: string
  name: string
  type: string
  expanded: boolean
  level: number
}

interface GraphLink extends d3.SimulationLinkDatum<GraphNode> {
  source: string | GraphNode
  target: string | GraphNode
}

export default function D3GraphPage() {
  const svgRef = useRef<SVGSVGElement>(null)
  const [nodes, setNodes] = useState<GraphNode[]>([
    { id: "root", name: "Ideai Platform", type: "platform", expanded: false, level: 0 },
  ])
  const [links, setLinks] = useState<GraphLink[]>([])

  const childNodeTemplates = {
    platform: [
      { name: "AI Engine", type: "engine" },
      { name: "Code Generator", type: "generator" },
      { name: "Analytics", type: "analytics" },
    ],
    engine: [
      { name: "GPT-5", type: "model" },
      { name: "Claude 4", type: "model" },
      { name: "Gemini Pro", type: "model" },
    ],
    generator: [
      { name: "React Builder", type: "builder" },
      { name: "API Builder", type: "builder" },
      { name: "DB Builder", type: "builder" },
    ],
    analytics: [
      { name: "User Metrics", type: "metric" },
      { name: "Performance", type: "metric" },
      { name: "Cost Analysis", type: "metric" },
    ],
  }

  const getNodeColor = (type: string) => {
    const colors: Record<string, string> = {
      platform: "var(--accent)",
      engine: "#3b82f6",
      generator: "#10b981",
      analytics: "#f59e0b",
      model: "#8b5cf6",
      builder: "#ec4899",
      metric: "#06b6d4",
    }
    return colors[type] || "var(--muted)"
  }

  const expandNode = (nodeId: string) => {
    const node = nodes.find((n) => n.id === nodeId)
    if (!node || node.expanded) return

    const templates = childNodeTemplates[node.type as keyof typeof childNodeTemplates]
    if (!templates) return

    const newNodes = templates.map((template, i) => ({
      id: `${nodeId}-child-${i}`,
      name: template.name,
      type: template.type,
      expanded: false,
      level: node.level + 1,
    }))

    const newLinks = newNodes.map((newNode) => ({
      source: nodeId,
      target: newNode.id,
    }))

    setNodes((prev) => [...prev, ...newNodes])
    setLinks((prev) => [...prev, ...newLinks])
    node.expanded = true
  }

  const collapseNode = (nodeId: string) => {
    const node = nodes.find((n) => n.id === nodeId)
    if (!node || !node.expanded) return

    const childIds = new Set<string>()
    const findChildren = (id: string) => {
      links.forEach((link) => {
        const source = typeof link.source === "string" ? link.source : link.source.id
        const target = typeof link.target === "string" ? link.target : link.target.id
        if (source === id) {
          childIds.add(target)
          findChildren(target)
        }
      })
    }
    findChildren(nodeId)

    setNodes((prev) => prev.filter((n) => !childIds.has(n.id)))
    setLinks((prev) =>
      prev.filter((link) => {
        const source = typeof link.source === "string" ? link.source : link.source.id
        const target = typeof link.target === "string" ? link.target : link.target.id
        return !childIds.has(source) && !childIds.has(target)
      }),
    )
    node.expanded = false
  }

  const resetGraph = () => {
    setNodes([{ id: "root", name: "Ideai Platform", type: "platform", expanded: false, level: 0 }])
    setLinks([])
  }

  useEffect(() => {
    if (!svgRef.current || nodes.length === 0) return

    const svg = d3.select(svgRef.current)
    const width = svgRef.current.clientWidth
    const height = svgRef.current.clientHeight

    svg.selectAll("*").remove()

    const g = svg.append("g")

    const zoom = d3
      .zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 4])
      .on("zoom", (event) => {
        g.attr("transform", event.transform)
      })

    svg.call(zoom as any)

    const simulation = d3
      .forceSimulation(nodes)
      .force(
        "link",
        d3
          .forceLink<GraphNode, GraphLink>(links)
          .id((d) => d.id)
          .distance(100),
      )
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collision", d3.forceCollide().radius(50))

    const link = g
      .append("g")
      .selectAll("line")
      .data(links)
      .join("line")
      .attr("stroke", "var(--border)")
      .attr("stroke-width", 2)
      .attr("stroke-opacity", 0.6)

    const node = g
      .append("g")
      .selectAll("g")
      .data(nodes)
      .join("g")
      .call(d3.drag<SVGGElement, GraphNode>().on("start", dragstarted).on("drag", dragged).on("end", dragended) as any)

    node
      .append("circle")
      .attr("r", 30)
      .attr("fill", (d) => getNodeColor(d.type))
      .attr("stroke", "var(--background)")
      .attr("stroke-width", 3)
      .style("cursor", "pointer")

    node
      .append("text")
      .text((d) => d.name)
      .attr("text-anchor", "middle")
      .attr("dy", 50)
      .attr("fill", "var(--foreground)")
      .attr("font-size", "12px")
      .attr("font-weight", "600")

    node
      .append("text")
      .text((d) => (d.expanded ? "−" : "+"))
      .attr("text-anchor", "middle")
      .attr("dy", 5)
      .attr("fill", "var(--background)")
      .attr("font-size", "20px")
      .attr("font-weight", "bold")
      .style("pointer-events", "none")

    node.on("click", (event, d) => {
      event.stopPropagation()
      if (d.expanded) {
        collapseNode(d.id)
      } else {
        expandNode(d.id)
      }
    })

    simulation.on("tick", () => {
      link
        .attr("x1", (d) => (d.source as GraphNode).x ?? 0)
        .attr("y1", (d) => (d.source as GraphNode).y ?? 0)
        .attr("x2", (d) => (d.target as GraphNode).x ?? 0)
        .attr("y2", (d) => (d.target as GraphNode).y ?? 0)

      node.attr("transform", (d) => `translate(${d.x ?? 0},${d.y ?? 0})`)
    })

    function dragstarted(event: any) {
      if (!event.active) simulation.alphaTarget(0.3).restart()
      event.subject.fx = event.subject.x
      event.subject.fy = event.subject.y
    }

    function dragged(event: any) {
      event.subject.fx = event.x
      event.subject.fy = event.y
    }

    function dragended(event: any) {
      if (!event.active) simulation.alphaTarget(0)
      event.subject.fx = null
      event.subject.fy = null
    }

    return () => {
      simulation.stop()
    }
  }, [nodes, links])

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-background pt-16">
        <div className="container mx-auto px-6 py-12">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2 text-foreground">D3.js Force-Directed Graph</h1>
            <p className="text-muted-foreground">
              Click nodes to expand infinite child nodes. Drag to reposition. Scroll to zoom.
            </p>
          </div>

          <Card className="p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
              <Button onClick={() => expandNode("root")} size="sm" variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Expand Root
              </Button>
              <Button onClick={() => collapseNode("root")} size="sm" variant="outline">
                <Minus className="w-4 h-4 mr-2" />
                Collapse Root
              </Button>
              <Button onClick={resetGraph} size="sm" variant="outline">
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset
              </Button>
              <div className="ml-auto text-sm text-muted-foreground">
                Nodes: {nodes.length} | Links: {links.length}
              </div>
            </div>

            <div className="relative w-full h-[600px] bg-card rounded-lg border border-border overflow-hidden">
              <svg ref={svgRef} className="w-full h-full" />
            </div>
          </Card>

          <div className="grid md:grid-cols-3 gap-4">
            <Card className="p-4">
              <h3 className="font-semibold mb-2 text-foreground">Interactive Nodes</h3>
              <p className="text-sm text-muted-foreground">Click any node to expand its children dynamically</p>
            </Card>
            <Card className="p-4">
              <h3 className="font-semibold mb-2 text-foreground">Physics Simulation</h3>
              <p className="text-sm text-muted-foreground">D3 force simulation creates natural layouts</p>
            </Card>
            <Card className="p-4">
              <h3 className="font-semibold mb-2 text-foreground">Infinite Depth</h3>
              <p className="text-sm text-muted-foreground">Nodes can expand to any depth level</p>
            </Card>
          </div>
        </div>
      </div>
    </>
  )
}
