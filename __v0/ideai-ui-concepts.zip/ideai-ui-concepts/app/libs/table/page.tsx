"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import {
  useReactTable,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  getPaginationRowModel,
  flexRender,
  type ColumnDef,
  type SortingState,
  type ColumnFiltersState,
} from "@tanstack/react-table"
import { ArrowUpDown, Search, ChevronLeft, ChevronRight } from "lucide-react"

interface Project {
  id: string
  name: string
  team: string
  status: string
  progress: number
  cost: string
  timeline: string
  ai_agents: number
}

const data: Project[] = [
  {
    id: "1",
    name: "E-commerce Platform",
    team: "AI Only",
    status: "In Progress",
    progress: 75,
    cost: "$450",
    timeline: "2 weeks",
    ai_agents: 8,
  },
  {
    id: "2",
    name: "Healthcare SaaS",
    team: "Hybrid",
    status: "Planning",
    progress: 20,
    cost: "$12,500",
    timeline: "6 weeks",
    ai_agents: 5,
  },
  {
    id: "3",
    name: "Finance Dashboard",
    team: "Human",
    status: "Completed",
    progress: 100,
    cost: "$85,000",
    timeline: "16 weeks",
    ai_agents: 0,
  },
  {
    id: "4",
    name: "Social Media App",
    team: "AI Only",
    status: "In Progress",
    progress: 60,
    cost: "$680",
    timeline: "3 weeks",
    ai_agents: 10,
  },
  {
    id: "5",
    name: "CRM System",
    team: "Hybrid",
    status: "In Progress",
    progress: 45,
    cost: "$8,200",
    timeline: "5 weeks",
    ai_agents: 6,
  },
  {
    id: "6",
    name: "Analytics Platform",
    team: "AI Only",
    status: "Completed",
    progress: 100,
    cost: "$920",
    timeline: "4 weeks",
    ai_agents: 8,
  },
  {
    id: "7",
    name: "IoT Dashboard",
    team: "Human",
    status: "Planning",
    progress: 10,
    cost: "$95,000",
    timeline: "20 weeks",
    ai_agents: 0,
  },
  {
    id: "8",
    name: "Booking System",
    team: "Hybrid",
    status: "In Progress",
    progress: 80,
    cost: "$6,500",
    timeline: "4 weeks",
    ai_agents: 4,
  },
  {
    id: "9",
    name: "Educational Portal",
    team: "AI Only",
    status: "Completed",
    progress: 100,
    cost: "$540",
    timeline: "2 weeks",
    ai_agents: 7,
  },
  {
    id: "10",
    name: "Inventory Manager",
    team: "Hybrid",
    status: "In Progress",
    progress: 55,
    cost: "$10,200",
    timeline: "7 weeks",
    ai_agents: 6,
  },
]

export default function TablePage() {
  const [sorting, setSorting] = useState<SortingState>([])
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([])
  const [globalFilter, setGlobalFilter] = useState("")

  const columns: ColumnDef<Project>[] = [
    {
      accessorKey: "name",
      header: ({ column }) => (
        <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
          Project Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => <div className="font-medium">{row.getValue("name")}</div>,
    },
    {
      accessorKey: "team",
      header: "Team Type",
      cell: ({ row }) => {
        const team = row.getValue("team") as string
        const colors = {
          "AI Only": "bg-blue-500/20 text-blue-400 border-blue-500/50",
          Hybrid: "bg-purple-500/20 text-purple-400 border-purple-500/50",
          Human: "bg-gray-500/20 text-gray-400 border-gray-500/50",
        }
        return (
          <span className={`px-2 py-1 rounded-full text-xs border ${colors[team as keyof typeof colors]}`}>{team}</span>
        )
      },
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        const status = row.getValue("status") as string
        const colors = {
          "In Progress": "bg-blue-500/20 text-blue-400",
          Planning: "bg-yellow-500/20 text-yellow-400",
          Completed: "bg-green-500/20 text-green-400",
        }
        return <span className={`px-2 py-1 rounded text-xs ${colors[status as keyof typeof colors]}`}>{status}</span>
      },
    },
    {
      accessorKey: "progress",
      header: ({ column }) => (
        <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
          Progress
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const progress = row.getValue("progress") as number
        return (
          <div className="flex items-center gap-2">
            <div className="w-full bg-muted rounded-full h-2">
              <div className="bg-accent h-2 rounded-full" style={{ width: `${progress}%` }} />
            </div>
            <span className="text-xs text-muted-foreground min-w-[3ch]">{progress}%</span>
          </div>
        )
      },
    },
    {
      accessorKey: "cost",
      header: ({ column }) => (
        <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
          Cost
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => <div className="font-mono">{row.getValue("cost")}</div>,
    },
    {
      accessorKey: "timeline",
      header: "Timeline",
    },
    {
      accessorKey: "ai_agents",
      header: ({ column }) => (
        <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
          AI Agents
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const agents = row.getValue("ai_agents") as number
        return <div className="text-center font-semibold">{agents > 0 ? agents : "—"}</div>
      },
    },
  ]

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
    state: {
      sorting,
      columnFilters,
      globalFilter,
    },
    initialState: {
      pagination: {
        pageSize: 6,
      },
    },
  })

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-background pt-16">
        <div className="container mx-auto px-6 py-12">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2 text-foreground">TanStack Table</h1>
            <p className="text-muted-foreground">
              Advanced data table with sorting, filtering, pagination, and custom cell rendering
            </p>
          </div>

          <Card className="p-6">
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search all columns..."
                  value={globalFilter ?? ""}
                  onChange={(e) => setGlobalFilter(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="rounded-lg border border-border overflow-hidden">
              <table className="w-full">
                <thead className="bg-muted/50">
                  {table.getHeaderGroups().map((headerGroup) => (
                    <tr key={headerGroup.id}>
                      {headerGroup.headers.map((header) => (
                        <th key={header.id} className="px-4 py-3 text-left text-sm font-semibold">
                          {header.isPlaceholder
                            ? null
                            : flexRender(header.column.columnDef.header, header.getContext())}
                        </th>
                      ))}
                    </tr>
                  ))}
                </thead>
                <tbody>
                  {table.getRowModel().rows.map((row) => (
                    <tr key={row.id} className="border-t border-border hover:bg-muted/30 transition-colors">
                      {row.getVisibleCells().map((cell) => (
                        <td key={cell.id} className="px-4 py-4 text-sm">
                          {flexRender(cell.column.columnDef.cell, cell.getContext())}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between mt-6">
              <div className="text-sm text-muted-foreground">
                Showing {table.getState().pagination.pageIndex * table.getState().pagination.pageSize + 1} to{" "}
                {Math.min(
                  (table.getState().pagination.pageIndex + 1) * table.getState().pagination.pageSize,
                  data.length,
                )}{" "}
                of {data.length} results
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => table.previousPage()}
                  disabled={!table.getCanPreviousPage()}
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </Button>
                <Button variant="outline" size="sm" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>
                  Next
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>

          <div className="grid md:grid-cols-3 gap-4 mt-6">
            <Card className="p-4">
              <h3 className="font-semibold mb-2 text-foreground">Advanced Sorting</h3>
              <p className="text-sm text-muted-foreground">Click column headers to sort data ascending or descending</p>
            </Card>
            <Card className="p-4">
              <h3 className="font-semibold mb-2 text-foreground">Global Search</h3>
              <p className="text-sm text-muted-foreground">Filter across all columns with instant results</p>
            </Card>
            <Card className="p-4">
              <h3 className="font-semibold mb-2 text-foreground">Custom Cells</h3>
              <p className="text-sm text-muted-foreground">Rich cell rendering with badges and progress bars</p>
            </Card>
          </div>
        </div>
      </div>
    </>
  )
}
