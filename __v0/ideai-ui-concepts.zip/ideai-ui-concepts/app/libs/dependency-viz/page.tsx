"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Canvas } from "@react-three/fiber"
import { OrbitControls, Text, Sphere, Line } from "@react-three/drei"

// Tree view data structure
const dependencyData = {
  name: "ideai-platform",
  type: "root",
  dependencies: [
    {
      name: "next",
      version: "16.0.10",
      type: "framework",
      dependencies: [
        { name: "react", version: "19.2.0", type: "lib" },
        { name: "react-dom", version: "19.2.0", type: "lib" },
      ],
    },
    {
      name: "framer-motion",
      version: "12.25.0",
      type: "animation",
      dependencies: [],
    },
    {
      name: "@xyflow/react",
      version: "12.3.4",
      type: "visualization",
      dependencies: [{ name: "d3", version: "7.9.0", type: "lib" }],
    },
    {
      name: "tailwindcss",
      version: "4.1.9",
      type: "styling",
      dependencies: [
        { name: "autoprefixer", version: "10.4.20", type: "tool" },
        { name: "postcss", version: "8.5", type: "tool" },
      ],
    },
  ],
}

// 3D Node Component
function DependencyNode({
  position,
  label,
  color,
}: { position: [number, number, number]; label: string; color: string }) {
  return (
    <group position={position}>
      <Sphere args={[0.3, 32, 32]}>
        <meshStandardMaterial color={color} />
      </Sphere>
      <Text position={[0, -0.6, 0]} fontSize={0.2} color="white" anchorX="center" anchorY="middle">
        {label}
      </Text>
    </group>
  )
}

// Recursive Tree Component
function TreeNode({ node, depth = 0, index = 0, totalSiblings = 1 }: any) {
  const hasChildren = node.dependencies && node.dependencies.length > 0
  const spacing = 200
  const verticalSpacing = 120

  return (
    <div className="relative">
      {/* Current Node */}
      <div className="flex items-center justify-center">
        <Card className="px-6 py-4 min-w-[200px] bg-card hover:bg-accent/10 transition-colors cursor-pointer border-2">
          <div className="space-y-1">
            <p className="font-mono font-bold text-sm">{node.name}</p>
            {node.version && <p className="text-xs text-muted-foreground">v{node.version}</p>}
            {node.type && <p className="text-xs text-accent capitalize">{node.type}</p>}
          </div>
        </Card>
      </div>

      {/* Children */}
      {hasChildren && (
        <div className="relative mt-8">
          {/* Connector line */}
          <div className="absolute left-1/2 -translate-x-1/2 w-0.5 h-8 bg-border -top-8" />

          <div className="flex items-start justify-center gap-8">
            {node.dependencies.map((child: any, idx: number) => (
              <div key={idx} className="relative">
                {/* Horizontal connector */}
                <div className="absolute left-1/2 -translate-x-1/2 w-0.5 h-8 bg-border -top-8" />
                <TreeNode node={child} depth={depth + 1} index={idx} totalSiblings={node.dependencies.length} />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// Circular Layout Component
function CircularDependencies() {
  const packages = [
    { name: "next", angle: 0, connections: [1, 2] },
    { name: "react", angle: 60, connections: [0, 3] },
    { name: "framer-motion", angle: 120, connections: [0] },
    { name: "tailwindcss", angle: 180, connections: [0, 4] },
    { name: "three.js", angle: 240, connections: [3] },
    { name: "@xyflow/react", angle: 300, connections: [0, 1] },
  ]

  const radius = 150
  const centerX = 200
  const centerY = 200

  return (
    <svg width="400" height="400" className="mx-auto">
      {/* Connections */}
      {packages.map((pkg, idx) => {
        const x1 = centerX + radius * Math.cos((pkg.angle * Math.PI) / 180)
        const y1 = centerY + radius * Math.sin((pkg.angle * Math.PI) / 180)

        return pkg.connections.map((targetIdx) => {
          const target = packages[targetIdx]
          const x2 = centerX + radius * Math.cos((target.angle * Math.PI) / 180)
          const y2 = centerY + radius * Math.sin((target.angle * Math.PI) / 180)

          return (
            <line
              key={`${idx}-${targetIdx}`}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="hsl(var(--border))"
              strokeWidth="2"
              opacity="0.3"
            />
          )
        })
      })}

      {/* Nodes */}
      {packages.map((pkg, idx) => {
        const x = centerX + radius * Math.cos((pkg.angle * Math.PI) / 180)
        const y = centerY + radius * Math.sin((pkg.angle * Math.PI) / 180)

        return (
          <g key={idx}>
            <circle
              cx={x}
              cy={y}
              r="30"
              fill="hsl(var(--accent))"
              stroke="hsl(var(--border))"
              strokeWidth="2"
              className="cursor-pointer hover:opacity-80 transition-opacity"
            />
            <text
              x={x}
              y={y}
              textAnchor="middle"
              dominantBaseline="middle"
              className="fill-accent-foreground text-xs font-mono font-bold pointer-events-none"
            >
              {pkg.name}
            </text>
          </g>
        )
      })}
    </svg>
  )
}

export default function DependencyVizPage() {
  const [viewMode, setViewMode] = useState<"3d" | "tree" | "circular">("3d")

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-20 px-6 pb-12">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-bold tracking-tight">Dependency Visualizer</h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Explore repository dependencies in 3D space, tree hierarchies, and circular layouts
            </p>
          </div>

          {/* View Tabs */}
          <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as any)} className="w-full">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
              <TabsTrigger value="3d">3D Network</TabsTrigger>
              <TabsTrigger value="tree">Tree View</TabsTrigger>
              <TabsTrigger value="circular">Circular</TabsTrigger>
            </TabsList>

            <TabsContent value="3d" className="mt-8">
              <Card className="overflow-hidden">
                <div style={{ height: "600px" }}>
                  <Canvas camera={{ position: [0, 0, 10], fov: 50 }}>
                    <ambientLight intensity={0.5} />
                    <pointLight position={[10, 10, 10]} />

                    {/* Root */}
                    <DependencyNode position={[0, 0, 0]} label="ideai" color="#3b82f6" />

                    {/* Level 1 */}
                    <DependencyNode position={[-3, 2, 0]} label="next" color="#00ff88" />
                    <DependencyNode position={[3, 2, 0]} label="react" color="#00ff88" />
                    <DependencyNode position={[-3, -2, 0]} label="three.js" color="#00ff88" />
                    <DependencyNode position={[3, -2, 0]} label="tailwind" color="#00ff88" />

                    {/* Level 2 */}
                    <DependencyNode position={[-5, 4, -2]} label="webpack" color="#ff0088" />
                    <DependencyNode position={[5, 4, -2]} label="react-dom" color="#ff0088" />

                    {/* Connections */}
                    <Line
                      points={[
                        [0, 0, 0],
                        [-3, 2, 0],
                      ]}
                      color="white"
                      lineWidth={2}
                      opacity={0.5}
                    />
                    <Line
                      points={[
                        [0, 0, 0],
                        [3, 2, 0],
                      ]}
                      color="white"
                      lineWidth={2}
                      opacity={0.5}
                    />
                    <Line
                      points={[
                        [0, 0, 0],
                        [-3, -2, 0],
                      ]}
                      color="white"
                      lineWidth={2}
                      opacity={0.5}
                    />
                    <Line
                      points={[
                        [0, 0, 0],
                        [3, -2, 0],
                      ]}
                      color="white"
                      lineWidth={2}
                      opacity={0.5}
                    />
                    <Line
                      points={[
                        [-3, 2, 0],
                        [-5, 4, -2],
                      ]}
                      color="white"
                      lineWidth={2}
                      opacity={0.3}
                    />
                    <Line
                      points={[
                        [3, 2, 0],
                        [5, 4, -2],
                      ]}
                      color="white"
                      lineWidth={2}
                      opacity={0.3}
                    />

                    <OrbitControls enableZoom enablePan enableRotate />
                  </Canvas>
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="tree" className="mt-8">
              <Card className="p-8 overflow-auto">
                <div className="min-w-max">
                  <TreeNode node={dependencyData} />
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="circular" className="mt-8">
              <Card className="p-8">
                <CircularDependencies />
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
