"use client"

import { useEffect, useRef } from "react"
import { Navigation } from "@/components/navigation"

export default function TimelineJSPage() {
  const timelineRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Load TimelineJS CSS
    const link = document.createElement("link")
    link.rel = "stylesheet"
    link.href = "https://cdn.knightlab.com/libs/timeline3/latest/css/timeline.css"
    document.head.appendChild(link)

    // Load TimelineJS script
    const script = document.createElement("script")
    script.src = "https://cdn.knightlab.com/libs/timeline3/latest/js/timeline.js"
    script.async = true

    script.onload = () => {
      if (timelineRef.current && (window as any).TL) {
        const timelineData = {
          title: {
            text: {
              headline: "Ideai Development Journey",
              text: "<p>From concept to AI-powered platform</p>",
            },
          },
          events: [
            {
              start_date: {
                year: "2024",
                month: "1",
              },
              text: {
                headline: "Concept Phase",
                text: "Initial idea: IDE + IDEA + AI = Ideai. Vision to replace entire dev teams with AI agents.",
              },
              background: {
                color: "#1a1a2e",
              },
            },
            {
              start_date: {
                year: "2024",
                month: "3",
              },
              text: {
                headline: "First AI Agent",
                text: "Developed the first AI agent 'CodeCraft' capable of writing full-stack applications.",
              },
              background: {
                color: "#16213e",
              },
            },
            {
              start_date: {
                year: "2024",
                month: "5",
              },
              text: {
                headline: "Team Expansion",
                text: "Added 5 more specialized AI agents: DesignMind, TestBot, DeployDrone, ScaleMaster, and DataWhiz.",
              },
              background: {
                color: "#0f3460",
              },
            },
            {
              start_date: {
                year: "2024",
                month: "7",
              },
              text: {
                headline: "First Production App",
                text: "Built and deployed first complete SaaS application in 3 weeks instead of 6 months.",
              },
              background: {
                color: "#533483",
              },
            },
            {
              start_date: {
                year: "2024",
                month: "9",
              },
              text: {
                headline: "Platform Launch",
                text: "Launched Ideai platform to beta users. Reduced development costs by 98% on average.",
              },
              background: {
                color: "#8b5cf6",
              },
            },
            {
              start_date: {
                year: "2024",
                month: "11",
              },
              text: {
                headline: "Multi-Modal AI",
                text: "Integrated GPT-5, Claude 4, and Gemini Pro for enhanced agent capabilities.",
              },
              background: {
                color: "#a855f7",
              },
            },
            {
              start_date: {
                year: "2025",
                month: "1",
              },
              text: {
                headline: "Enterprise Features",
                text: "Added team collaboration, white-label options, and enterprise-grade security.",
              },
              background: {
                color: "#c084fc",
              },
            },
            {
              start_date: {
                year: "2025",
                month: "3",
              },
              text: {
                headline: "Global Expansion",
                text: "Reached 10,000 users across 50 countries. Building over 1,000 apps per month.",
              },
              background: {
                color: "#e9d5ff",
              },
            },
            {
              start_date: {
                year: "2025",
                month: "6",
              },
              text: {
                headline: "AI Marketplace",
                text: "Launched marketplace for custom AI agents and pre-built templates.",
              },
              background: {
                color: "#6366f1",
              },
            },
            {
              start_date: {
                year: "2025",
                month: "9",
              },
              text: {
                headline: "The Future",
                text: "Next: Real-time collaboration, voice-to-code, and autonomous project management.",
              },
              background: {
                color: "#000000",
              },
            },
          ],
        }
        ;new (window as any).TL.Timeline(timelineRef.current, timelineData, {
          scale_factor: 2,
          initial_zoom: 2,
          hash_bookmark: true,
        })
      }
    }

    document.body.appendChild(script)

    return () => {
      if (document.head.contains(link)) {
        document.head.removeChild(link)
      }
      if (document.body.contains(script)) {
        document.body.removeChild(script)
      }
    }
  }, [])

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-background pt-16">
        <div className="container mx-auto px-6 py-12">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">TimelineJS Demo</h1>
            <p className="text-muted-foreground">
              Interactive timeline showing the journey of Ideai from concept to platform
            </p>
          </div>

          <div
            ref={timelineRef}
            className="rounded-lg border border-border overflow-hidden bg-card"
            style={{ height: "calc(100vh - 280px)" }}
          />
        </div>
      </div>
    </>
  )
}
