"use client"

import { useState, useCallback } from "react"
import { Navigation } from "@/components/navigation"
import {
  ReactFlow,
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  type Node,
  type Edge,
  type Connection,
  BackgroundVariant,
} from "@xyflow/react"
import "@xyflow/react/dist/style.css"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, RotateCcw } from "lucide-react"

const initialNodes: Node[] = [
  {
    id: "1",
    type: "input",
    data: { label: "Start: Build SaaS App?" },
    position: { x: 250, y: 0 },
    style: {
      background: "hsl(var(--accent))",
      color: "hsl(var(--accent-foreground))",
      border: "2px solid hsl(var(--accent))",
    },
  },
  {
    id: "2",
    data: { label: "Use Human Team?" },
    position: { x: 100, y: 100 },
    style: { background: "hsl(var(--muted))", border: "2px solid hsl(var(--border))" },
  },
  {
    id: "3",
    data: { label: "Use AI Bots?" },
    position: { x: 400, y: 100 },
    style: { background: "hsl(var(--muted))", border: "2px solid hsl(var(--border))" },
  },
  {
    id: "4",
    data: { label: "Cost: $1.2M/year\nTime: 12 months" },
    position: { x: 0, y: 200 },
    style: { background: "hsl(var(--destructive))", color: "hsl(var(--destructive-foreground))" },
  },
  {
    id: "5",
    data: { label: "Hybrid: Human + AI" },
    position: { x: 200, y: 200 },
    style: { background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" },
  },
  {
    id: "6",
    data: { label: "Cost: $50k/year\nTime: 3 months" },
    position: { x: 400, y: 200 },
    style: { background: "hsl(var(--accent))", color: "hsl(var(--accent-foreground))" },
  },
  {
    id: "7",
    data: { label: "Full AI Suite" },
    position: { x: 600, y: 200 },
    style: { background: "hsl(var(--accent))", color: "hsl(var(--accent-foreground))" },
  },
  {
    id: "8",
    type: "output",
    data: { label: "Deploy to Production" },
    position: { x: 300, y: 300 },
    style: {
      background: "hsl(var(--accent))",
      color: "hsl(var(--accent-foreground))",
      border: "3px solid hsl(var(--accent))",
    },
  },
]

const initialEdges: Edge[] = [
  { id: "e1-2", source: "1", target: "2", label: "Yes", animated: true },
  { id: "e1-3", source: "1", target: "3", label: "Maybe", animated: true },
  { id: "e2-4", source: "2", target: "4", label: "Traditional" },
  { id: "e2-5", source: "2", target: "5", label: "With AI Support" },
  { id: "e3-6", source: "3", target: "6", label: "Supervised" },
  { id: "e3-7", source: "3", target: "7", label: "Autonomous" },
  { id: "e4-8", source: "4", target: "8" },
  { id: "e5-8", source: "5", target: "8" },
  { id: "e6-8", source: "6", target: "8" },
  { id: "e7-8", source: "7", target: "8" },
]

export default function DecisionTreePage() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges)
  const [decisions, setDecisions] = useState<string[]>([])

  const onConnect = useCallback((params: Connection | Edge) => setEdges((eds) => addEdge(params, eds)), [setEdges])

  const simulateDecision = () => {
    const path = ["Start: Build SaaS App?", "Use AI Bots?", "Cost: $50k/year", "Deploy to Production"]
    setDecisions(path)
  }

  const resetDecision = () => {
    setDecisions([])
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-20 px-6 pb-12">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-bold tracking-tight">Decision Tree Visualizer</h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Interactive decision flow showing how AI transforms expensive software development choices into efficient
              automated pathways
            </p>
          </div>

          {/* Controls */}
          <Card>
            <CardHeader>
              <CardTitle>Decision Analysis</CardTitle>
              <CardDescription>Run decision simulations and analyze outcomes</CardDescription>
            </CardHeader>
            <CardContent className="flex items-center gap-4">
              <Button onClick={simulateDecision} className="gap-2">
                <Play className="w-4 h-4" />
                Run Decision Simulation
              </Button>
              <Button onClick={resetDecision} variant="outline" className="gap-2 bg-transparent">
                <RotateCcw className="w-4 h-4" />
                Reset
              </Button>
              {decisions.length > 0 && (
                <div className="flex items-center gap-2 ml-4">
                  <span className="text-sm text-muted-foreground">Path:</span>
                  {decisions.map((decision, idx) => (
                    <Badge key={idx} variant="secondary">
                      {decision}
                    </Badge>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* React Flow Canvas */}
          <Card className="overflow-hidden">
            <div style={{ height: "600px" }}>
              <ReactFlow
                nodes={nodes}
                edges={edges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onConnect={onConnect}
                fitView
                className="bg-background"
              >
                <Controls />
                <MiniMap />
                <Background variant={BackgroundVariant.Dots} gap={12} size={1} />
              </ReactFlow>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
