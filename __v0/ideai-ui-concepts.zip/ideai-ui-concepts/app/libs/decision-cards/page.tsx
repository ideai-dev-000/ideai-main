"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { motion, AnimatePresence } from "framer-motion"
import { Check, X, AlertCircle, TrendingUp, Clock, DollarSign, Users } from "lucide-react"

interface DecisionNode {
  id: string
  question: string
  description: string
  options: DecisionOption[]
}

interface DecisionOption {
  id: string
  label: string
  icon: any
  cost: string
  time: string
  team: string
  pros: string[]
  cons: string[]
  nextNode?: string
}

const decisionTree: Record<string, DecisionNode> = {
  start: {
    id: "start",
    question: "How do you want to build your SaaS?",
    description: "Choose your development approach",
    options: [
      {
        id: "human",
        label: "Human Team",
        icon: Users,
        cost: "$1.2M/year",
        time: "12 months",
        team: "10 people",
        pros: ["Deep expertise", "Creative problem solving", "Flexible thinking"],
        cons: ["Expensive salaries", "Slow iteration", "Limited availability", "Vacation time"],
        nextNode: "human-setup",
      },
      {
        id: "ai",
        label: "AI Bots",
        icon: TrendingUp,
        cost: "$50k/year",
        time: "3 months",
        team: "10 bots",
        pros: ["24/7 availability", "Instant scaling", "Consistent quality", "No breaks needed"],
        cons: ["Requires oversight", "Learning curve", "Needs clear specs"],
        nextNode: "ai-setup",
      },
    ],
  },
  "human-setup": {
    id: "human-setup",
    question: "How will you manage the human team?",
    description: "Choose your management style",
    options: [
      {
        id: "traditional",
        label: "Traditional Management",
        icon: Users,
        cost: "$1.5M/year",
        time: "14 months",
        team: "12 people",
        pros: ["Proven process", "Clear hierarchy"],
        cons: ["High overhead", "Slow decisions"],
      },
      {
        id: "agile",
        label: "Agile with AI Tools",
        icon: TrendingUp,
        cost: "$800k/year",
        time: "8 months",
        team: "8 people + AI",
        pros: ["Faster iteration", "Lower cost", "AI assistance"],
        cons: ["Change management", "Training needed"],
      },
    ],
  },
  "ai-setup": {
    id: "ai-setup",
    question: "What level of AI automation?",
    description: "Choose your AI deployment model",
    options: [
      {
        id: "supervised",
        label: "Supervised AI",
        icon: AlertCircle,
        cost: "$75k/year",
        time: "4 months",
        team: "1 human + 10 bots",
        pros: ["Human oversight", "Lower risk", "Gradual adoption"],
        cons: ["Slightly slower", "Human bottleneck"],
      },
      {
        id: "autonomous",
        label: "Fully Autonomous",
        icon: TrendingUp,
        cost: "$30k/year",
        time: "2 months",
        team: "10 bots",
        pros: ["Maximum speed", "Lowest cost", "True automation"],
        cons: ["Requires trust", "Initial setup time"],
      },
    ],
  },
}

export default function DecisionCardsPage() {
  const [currentNode, setCurrentNode] = useState("start")
  const [path, setPath] = useState<string[]>([])
  const [selectedOption, setSelectedOption] = useState<string | null>(null)

  const node = decisionTree[currentNode]

  const handleSelect = (option: DecisionOption) => {
    setSelectedOption(option.id)
    setPath([...path, option.label])

    if (option.nextNode) {
      setTimeout(() => {
        setCurrentNode(option.nextNode!)
        setSelectedOption(null)
      }, 1000)
    }
  }

  const reset = () => {
    setCurrentNode("start")
    setPath([])
    setSelectedOption(null)
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-20 px-6 pb-12">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-bold tracking-tight">Visual Decision Builder</h1>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Step through decisions with interactive cards showing costs, timelines, and trade-offs
            </p>
          </div>

          {/* Path */}
          {path.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Your Decision Path</CardTitle>
              </CardHeader>
              <CardContent className="flex items-center gap-2 flex-wrap">
                {path.map((step, idx) => (
                  <Badge key={idx} variant="secondary" className="text-sm py-1.5 px-3">
                    {step}
                  </Badge>
                ))}
                <Button onClick={reset} variant="ghost" size="sm" className="ml-auto">
                  Start Over
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Question */}
          <div className="text-center space-y-2">
            <h2 className="text-3xl font-bold">{node.question}</h2>
            <p className="text-muted-foreground">{node.description}</p>
          </div>

          {/* Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            <AnimatePresence mode="wait">
              {node.options.map((option) => {
                const Icon = option.icon
                const isSelected = selectedOption === option.id

                return (
                  <motion.div
                    key={option.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card
                      className={`cursor-pointer transition-all hover:shadow-xl hover:scale-[1.02] ${
                        isSelected ? "ring-2 ring-accent shadow-xl scale-[1.02]" : ""
                      }`}
                      onClick={() => handleSelect(option)}
                    >
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className="p-2 rounded-lg bg-accent/10">
                              <Icon className="w-6 h-6 text-accent" />
                            </div>
                            <div>
                              <CardTitle className="text-xl">{option.label}</CardTitle>
                            </div>
                          </div>
                          {isSelected && (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              className="p-1 rounded-full bg-accent"
                            >
                              <Check className="w-4 h-4 text-accent-foreground" />
                            </motion.div>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {/* Metrics */}
                        <div className="grid grid-cols-3 gap-3">
                          <div className="flex items-center gap-2 text-sm">
                            <DollarSign className="w-4 h-4 text-muted-foreground" />
                            <span className="font-medium">{option.cost}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Clock className="w-4 h-4 text-muted-foreground" />
                            <span className="font-medium">{option.time}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Users className="w-4 h-4 text-muted-foreground" />
                            <span className="font-medium">{option.team}</span>
                          </div>
                        </div>

                        {/* Pros */}
                        <div className="space-y-2">
                          <p className="text-sm font-medium text-muted-foreground">Pros</p>
                          <div className="space-y-1">
                            {option.pros.map((pro, idx) => (
                              <div key={idx} className="flex items-start gap-2 text-sm">
                                <Check className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                                <span>{pro}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Cons */}
                        <div className="space-y-2">
                          <p className="text-sm font-medium text-muted-foreground">Cons</p>
                          <div className="space-y-1">
                            {option.cons.map((con, idx) => (
                              <div key={idx} className="flex items-start gap-2 text-sm">
                                <X className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                                <span className="text-muted-foreground">{con}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  )
}
