"use client"

import { Navigation } from "@/components/navigation"
import { useEditor, EditorContent } from "@tiptap/react"
import { StarterKit } from "@tiptap/starter-kit"
import { Underline } from "@tiptap/extension-underline"
import { TextAlign } from "@tiptap/extension-text-align"
import { Highlight } from "@tiptap/extension-highlight"
import { Image } from "@tiptap/extension-image"
import { Link } from "@tiptap/extension-link"
import { Table } from "@tiptap/extension-table"
import { TableRow } from "@tiptap/extension-table-row"
import { TableHeader } from "@tiptap/extension-table-header"
import { TableCell } from "@tiptap/extension-table-cell"
import { TextStyle } from "@tiptap/extension-text-style"
import { Color } from "@tiptap/extension-color"
import { FontFamily } from "@tiptap/extension-font-family"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import {
  Bold,
  Italic,
  UnderlineIcon,
  Strikethrough,
  Code,
  Heading1,
  Heading2,
  Heading3,
  List,
  ListOrdered,
  Quote,
  Undo,
  Redo,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Highlighter,
  LinkIcon,
  ImageIcon,
  TableIcon,
  FileText,
} from "lucide-react"
import { useState } from "react"

export default function EditorPage() {
  const [wordCount, setWordCount] = useState(0)
  const [charCount, setCharCount] = useState(0)

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: {
          levels: [1, 2, 3],
        },
      }),
      Underline,
      TextAlign.configure({
        types: ["heading", "paragraph"],
      }),
      Highlight.configure({
        multicolor: true,
      }),
      Image,
      Link.configure({
        openOnClick: false,
      }),
      Table.configure({
        resizable: true,
      }),
      TableRow,
      TableHeader,
      TableCell,
      TextStyle,
      Color,
      FontFamily,
    ],
    content: `
      <h1>Welcome to Ideai Word Processor</h1>
      <p>This is a professional-grade WYSIWYG editor built with <strong>Tiptap</strong>, the most performant rich text editor for Next.js.</p>
      <h2>Key Features</h2>
      <ul>
        <li>Rich text formatting with bold, italic, underline, and strikethrough</li>
        <li>Multiple heading levels and text alignment options</li>
        <li>Lists (ordered and unordered), blockquotes, and code blocks</li>
        <li>Text highlighting with multiple colors</li>
        <li>Image embedding and link insertion</li>
        <li>Table support with resizable columns</li>
        <li>Real-time word and character count</li>
        <li>Undo/redo functionality</li>
      </ul>
      <h2>Try It Out</h2>
      <p>Start typing below to experience the power of a modern word processor. Use the toolbar above to format your text, insert images, create tables, and more.</p>
      <blockquote>
        "The best way to predict the future is to invent it." - Alan Kay
      </blockquote>
      <p>This editor is built for 2028 and beyond, showcasing how AI-powered platforms like Ideai can deliver enterprise-grade text editing experiences.</p>
    `,
    editorProps: {
      attributes: {
        class: "focus:outline-none min-h-[500px] p-8 text-foreground",
      },
    },
    onUpdate: ({ editor }) => {
      const text = editor.getText()
      const words = text
        .trim()
        .split(/\s+/)
        .filter((word) => word.length > 0)
      setWordCount(words.length)
      setCharCount(text.length)
    },
  })

  if (!editor) {
    return null
  }

  const addImage = () => {
    const url = window.prompt("Enter image URL:")
    if (url) {
      editor.chain().focus().setImage({ src: url }).run()
    }
  }

  const addLink = () => {
    const url = window.prompt("Enter URL:")
    if (url) {
      editor.chain().focus().setLink({ href: url }).run()
    }
  }

  const addTable = () => {
    editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run()
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <style jsx global>{`
        .ProseMirror h1 {
          font-size: 2.25rem;
          font-weight: 700;
          margin-top: 1.5rem;
          margin-bottom: 1rem;
          line-height: 1.2;
          color: hsl(var(--foreground));
        }
        .ProseMirror h2 {
          font-size: 1.875rem;
          font-weight: 600;
          margin-top: 1.25rem;
          margin-bottom: 0.875rem;
          line-height: 1.3;
          color: hsl(var(--foreground));
        }
        .ProseMirror h3 {
          font-size: 1.5rem;
          font-weight: 600;
          margin-top: 1rem;
          margin-bottom: 0.75rem;
          line-height: 1.4;
          color: hsl(var(--foreground));
        }
        .ProseMirror p {
          margin-top: 0.75rem;
          margin-bottom: 0.75rem;
          line-height: 1.6;
          color: hsl(var(--foreground));
        }
        .ProseMirror ul,
        .ProseMirror ol {
          padding-left: 1.5rem;
          margin-top: 0.75rem;
          margin-bottom: 0.75rem;
        }
        .ProseMirror ul li,
        .ProseMirror ol li {
          margin-top: 0.5rem;
          margin-bottom: 0.5rem;
          line-height: 1.6;
          color: hsl(var(--foreground));
        }
        .ProseMirror ul {
          list-style-type: disc;
        }
        .ProseMirror ol {
          list-style-type: decimal;
        }
        .ProseMirror blockquote {
          border-left: 4px solid hsl(var(--accent));
          padding-left: 1rem;
          margin: 1.5rem 0;
          font-style: italic;
          color: hsl(var(--muted-foreground));
        }
        .ProseMirror code {
          background-color: hsl(var(--muted));
          padding: 0.125rem 0.375rem;
          border-radius: 0.25rem;
          font-size: 0.875em;
          font-family: monospace;
          color: hsl(var(--foreground));
        }
        .ProseMirror pre {
          background-color: hsl(var(--muted));
          padding: 1rem;
          border-radius: 0.5rem;
          overflow-x: auto;
          margin: 1rem 0;
        }
        .ProseMirror pre code {
          background: none;
          padding: 0;
          color: hsl(var(--foreground));
        }
        .ProseMirror strong {
          font-weight: 700;
        }
        .ProseMirror em {
          font-style: italic;
        }
        .ProseMirror u {
          text-decoration: underline;
        }
        .ProseMirror s {
          text-decoration: line-through;
        }
        .ProseMirror a {
          color: hsl(var(--primary));
          text-decoration: underline;
          cursor: pointer;
        }
        .ProseMirror a:hover {
          color: hsl(var(--primary) / 0.8);
        }
        .ProseMirror img {
          max-width: 100%;
          height: auto;
          border-radius: 0.5rem;
          margin: 1rem 0;
        }
        .ProseMirror mark {
          background-color: hsl(var(--accent));
          padding: 0.125rem 0.25rem;
          border-radius: 0.125rem;
        }
        .ProseMirror table {
          border-collapse: collapse;
          table-layout: fixed;
          width: 100%;
          margin: 1.5rem 0;
          overflow: hidden;
        }
        .ProseMirror table td,
        .ProseMirror table th {
          min-width: 1em;
          border: 2px solid hsl(var(--border));
          padding: 0.5rem 0.75rem;
          vertical-align: top;
          box-sizing: border-box;
          position: relative;
          color: hsl(var(--foreground));
        }
        .ProseMirror table th {
          font-weight: 700;
          text-align: left;
          background-color: hsl(var(--muted));
        }
        .ProseMirror table .selectedCell {
          background-color: hsl(var(--accent) / 0.3);
        }
        .ProseMirror table .column-resize-handle {
          position: absolute;
          right: -2px;
          top: 0;
          bottom: -2px;
          width: 4px;
          background-color: hsl(var(--primary));
          pointer-events: none;
        }
        .ProseMirror:focus {
          outline: none;
        }
      `}</style>

      <div className="pt-20 pb-12">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <h1 className="text-4xl font-bold mb-2">Tiptap Word Processor</h1>
              <p className="text-muted-foreground">
                Professional-grade WYSIWYG editor powered by Tiptap and ProseMirror
              </p>
            </div>

            {/* Editor Container */}
            <div className="bg-card border border-border rounded-lg shadow-lg overflow-hidden">
              {/* Toolbar */}
              <div className="border-b border-border bg-muted/30 p-3 flex flex-wrap gap-1">
                {/* Text Formatting */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().toggleBold().run()}
                  className={editor.isActive("bold") ? "bg-accent" : ""}
                >
                  <Bold className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().toggleItalic().run()}
                  className={editor.isActive("italic") ? "bg-accent" : ""}
                >
                  <Italic className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().toggleUnderline().run()}
                  className={editor.isActive("underline") ? "bg-accent" : ""}
                >
                  <UnderlineIcon className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().toggleStrike().run()}
                  className={editor.isActive("strike") ? "bg-accent" : ""}
                >
                  <Strikethrough className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().toggleCode().run()}
                  className={editor.isActive("code") ? "bg-accent" : ""}
                >
                  <Code className="w-4 h-4" />
                </Button>

                <Separator orientation="vertical" className="h-8 mx-1" />

                {/* Headings */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
                  className={editor.isActive("heading", { level: 1 }) ? "bg-accent" : ""}
                >
                  <Heading1 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
                  className={editor.isActive("heading", { level: 2 }) ? "bg-accent" : ""}
                >
                  <Heading2 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
                  className={editor.isActive("heading", { level: 3 }) ? "bg-accent" : ""}
                >
                  <Heading3 className="w-4 h-4" />
                </Button>

                <Separator orientation="vertical" className="h-8 mx-1" />

                {/* Lists */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().toggleBulletList().run()}
                  className={editor.isActive("bulletList") ? "bg-accent" : ""}
                >
                  <List className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().toggleOrderedList().run()}
                  className={editor.isActive("orderedList") ? "bg-accent" : ""}
                >
                  <ListOrdered className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().toggleBlockquote().run()}
                  className={editor.isActive("blockquote") ? "bg-accent" : ""}
                >
                  <Quote className="w-4 h-4" />
                </Button>

                <Separator orientation="vertical" className="h-8 mx-1" />

                {/* Alignment */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().setTextAlign("left").run()}
                  className={editor.isActive({ textAlign: "left" }) ? "bg-accent" : ""}
                >
                  <AlignLeft className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().setTextAlign("center").run()}
                  className={editor.isActive({ textAlign: "center" }) ? "bg-accent" : ""}
                >
                  <AlignCenter className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().setTextAlign("right").run()}
                  className={editor.isActive({ textAlign: "right" }) ? "bg-accent" : ""}
                >
                  <AlignRight className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().setTextAlign("justify").run()}
                  className={editor.isActive({ textAlign: "justify" }) ? "bg-accent" : ""}
                >
                  <AlignJustify className="w-4 h-4" />
                </Button>

                <Separator orientation="vertical" className="h-8 mx-1" />

                {/* Highlight */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().toggleHighlight().run()}
                  className={editor.isActive("highlight") ? "bg-accent" : ""}
                >
                  <Highlighter className="w-4 h-4" />
                </Button>

                <Separator orientation="vertical" className="h-8 mx-1" />

                {/* Insert Options */}
                <Button variant="ghost" size="sm" onClick={addLink}>
                  <LinkIcon className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={addImage}>
                  <ImageIcon className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={addTable}>
                  <TableIcon className="w-4 h-4" />
                </Button>

                <Separator orientation="vertical" className="h-8 mx-1" />

                {/* Undo/Redo */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().undo().run()}
                  disabled={!editor.can().undo()}
                >
                  <Undo className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => editor.chain().focus().redo().run()}
                  disabled={!editor.can().redo()}
                >
                  <Redo className="w-4 h-4" />
                </Button>
              </div>

              {/* Editor Content */}
              <div className="bg-background">
                <EditorContent editor={editor} />
              </div>

              {/* Footer Stats */}
              <div className="border-t border-border bg-muted/30 p-3 flex items-center justify-between text-sm text-muted-foreground">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    {wordCount} words
                  </span>
                  <span>{charCount} characters</span>
                </div>
                <div className="text-xs">Powered by Tiptap + ProseMirror</div>
              </div>
            </div>

            {/* Features Grid */}
            <div className="mt-12 grid md:grid-cols-3 gap-6">
              <div className="p-6 border border-border rounded-lg bg-card">
                <h3 className="font-semibold mb-2">Performant</h3>
                <p className="text-sm text-muted-foreground">
                  Built on ProseMirror for maximum performance with large documents
                </p>
              </div>
              <div className="p-6 border border-border rounded-lg bg-card">
                <h3 className="font-semibold mb-2">Extensible</h3>
                <p className="text-sm text-muted-foreground">Add custom extensions and build exactly what you need</p>
              </div>
              <div className="p-6 border border-border rounded-lg bg-card">
                <h3 className="font-semibold mb-2">Headless</h3>
                <p className="text-sm text-muted-foreground">Complete control over styling and behavior with React</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
