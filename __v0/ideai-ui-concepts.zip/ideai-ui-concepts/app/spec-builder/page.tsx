"use client"

import { useState } from "react"
import { Navigation } from "@/components/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { FileText, Mic, MicOff, GitBranch, Network, Plus, Trash2, Check, Download, Upload } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"

interface Requirement {
  id: string
  title: string
  description: string
  priority: "high" | "medium" | "low"
  status: "pending" | "in-progress" | "complete"
}

interface Note {
  id: string
  content: string
  timestamp: Date
}

interface MindMapNode {
  id: string
  label: string
  x: number
  y: number
  children: string[]
}

export default function SpecBuilderPage() {
  const [activeTab, setActiveTab] = useState("spec")
  const [requirements, setRequirements] = useState<Requirement[]>([
    {
      id: "1",
      title: "User Authentication",
      description: "Implement secure login/logout with JWT tokens",
      priority: "high",
      status: "complete",
    },
    {
      id: "2",
      title: "Dashboard UI",
      description: "Create responsive dashboard with charts and metrics",
      priority: "high",
      status: "in-progress",
    },
    {
      id: "3",
      title: "API Integration",
      description: "Connect to third-party payment gateway",
      priority: "medium",
      status: "pending",
    },
  ])
  const [notes, setNotes] = useState<Note[]>([
    { id: "1", content: "Team meeting on Friday to discuss MVP scope", timestamp: new Date() },
  ])
  const [newReqTitle, setNewReqTitle] = useState("")
  const [newReqDesc, setNewReqDesc] = useState("")
  const [newNote, setNewNote] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [transcript, setTranscript] = useState("")

  const addRequirement = () => {
    if (!newReqTitle) return
    const newReq: Requirement = {
      id: Date.now().toString(),
      title: newReqTitle,
      description: newReqDesc,
      priority: "medium",
      status: "pending",
    }
    setRequirements([...requirements, newReq])
    setNewReqTitle("")
    setNewReqDesc("")
  }

  const toggleStatus = (id: string) => {
    setRequirements(
      requirements.map((req) => {
        if (req.id === id) {
          const statusFlow: Record<string, "pending" | "in-progress" | "complete"> = {
            pending: "in-progress",
            "in-progress": "complete",
            complete: "pending",
          }
          return { ...req, status: statusFlow[req.status] }
        }
        return req
      }),
    )
  }

  const deleteRequirement = (id: string) => {
    setRequirements(requirements.filter((req) => req.id !== id))
  }

  const addNote = () => {
    if (!newNote) return
    const note: Note = {
      id: Date.now().toString(),
      content: newNote,
      timestamp: new Date(),
    }
    setNotes([note, ...notes])
    setNewNote("")
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)
    if (!isRecording) {
      // Simulate transcription
      setTimeout(() => {
        setTranscript(
          "This is a demo transcription. In production, this would use the Web Speech API or a service like Deepgram/AssemblyAI to transcribe audio in real-time.",
        )
      }, 2000)
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "text-red-500"
      case "medium":
        return "text-yellow-500"
      case "low":
        return "text-green-500"
      default:
        return "text-muted-foreground"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "complete":
        return "bg-green-500/10 text-green-500 border-green-500/20"
      case "in-progress":
        return "bg-blue-500/10 text-blue-500 border-blue-500/20"
      case "pending":
        return "bg-muted text-muted-foreground border-border"
      default:
        return "bg-muted text-muted-foreground border-border"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="container mx-auto px-6 pt-24 pb-16">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Spec Builder Suite</h1>
          <p className="text-muted-foreground">
            Complete specification and planning toolkit optimized for iPad and touch interfaces
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8">
            <TabsTrigger value="spec" className="gap-2">
              <FileText className="w-4 h-4" />
              Spec Builder
            </TabsTrigger>
            <TabsTrigger value="notes" className="gap-2">
              <FileText className="w-4 h-4" />
              Notes
            </TabsTrigger>
            <TabsTrigger value="recorder" className="gap-2">
              <Mic className="w-4 h-4" />
              Recorder
            </TabsTrigger>
            <TabsTrigger value="mindmap" className="gap-2">
              <Network className="w-4 h-4" />
              Mind Map
            </TabsTrigger>
            <TabsTrigger value="workflow" className="gap-2">
              <GitBranch className="w-4 h-4" />
              Workflow
            </TabsTrigger>
          </TabsList>

          {/* Spec Builder Tab */}
          <TabsContent value="spec" className="space-y-6">
            <Card className="p-6">
              <h2 className="text-2xl font-bold mb-4">Project Requirements</h2>

              {/* Add new requirement */}
              <div className="space-y-4 mb-6 p-4 bg-muted/30 rounded-lg">
                <Input
                  placeholder="Requirement title..."
                  value={newReqTitle}
                  onChange={(e) => setNewReqTitle(e.target.value)}
                  className="text-lg"
                />
                <Textarea
                  placeholder="Requirement description..."
                  value={newReqDesc}
                  onChange={(e) => setNewReqDesc(e.target.value)}
                  rows={3}
                />
                <Button onClick={addRequirement} className="w-full sm:w-auto">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Requirement
                </Button>
              </div>

              {/* Requirements list */}
              <ScrollArea className="h-[500px]">
                <div className="space-y-4">
                  {requirements.map((req) => (
                    <Card key={req.id} className="p-4 hover:shadow-lg transition-shadow">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-3 flex-wrap">
                            <h3 className="font-semibold text-lg">{req.title}</h3>
                            <Badge variant="outline" className={getStatusColor(req.status)}>
                              {req.status}
                            </Badge>
                            <span className={`text-sm font-medium ${getPriorityColor(req.priority)}`}>
                              {req.priority} priority
                            </span>
                          </div>
                          <p className="text-muted-foreground">{req.description}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => toggleStatus(req.id)}
                            className="touch-manipulation"
                          >
                            <Check className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteRequirement(req.id)}
                            className="text-destructive touch-manipulation"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </ScrollArea>

              <div className="mt-6 flex gap-4">
                <Button variant="outline" className="flex-1 bg-transparent">
                  <Download className="w-4 h-4 mr-2" />
                  Export Spec
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent">
                  <Upload className="w-4 h-4 mr-2" />
                  Import Spec
                </Button>
              </div>
            </Card>
          </TabsContent>

          {/* Notes Tab */}
          <TabsContent value="notes" className="space-y-6">
            <Card className="p-6">
              <h2 className="text-2xl font-bold mb-4">Project Notes</h2>

              <div className="space-y-4 mb-6">
                <Textarea
                  placeholder="Write your note here..."
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  rows={4}
                  className="text-base"
                />
                <Button onClick={addNote} className="w-full sm:w-auto">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Note
                </Button>
              </div>

              <ScrollArea className="h-[500px]">
                <div className="space-y-3">
                  {notes.map((note) => (
                    <Card key={note.id} className="p-4 bg-muted/30">
                      <p className="text-sm mb-2">{note.content}</p>
                      <p className="text-xs text-muted-foreground">{note.timestamp.toLocaleString()}</p>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </Card>
          </TabsContent>

          {/* Recorder Tab */}
          <TabsContent value="recorder" className="space-y-6">
            <Card className="p-6">
              <h2 className="text-2xl font-bold mb-4">Voice Recorder & Transcriber</h2>

              <div className="flex flex-col items-center gap-6 py-12">
                <Button
                  size="lg"
                  variant={isRecording ? "destructive" : "default"}
                  onClick={toggleRecording}
                  className="w-32 h-32 rounded-full touch-manipulation"
                >
                  {isRecording ? <MicOff className="w-12 h-12" /> : <Mic className="w-12 h-12" />}
                </Button>

                <div className="text-center">
                  <p className="text-lg font-semibold mb-2">
                    {isRecording ? "Recording..." : "Tap to start recording"}
                  </p>
                  <p className="text-sm text-muted-foreground">Voice will be transcribed in real-time</p>
                </div>

                {transcript && (
                  <Card className="w-full p-6 bg-muted/30">
                    <h3 className="font-semibold mb-3">Transcription</h3>
                    <p className="text-muted-foreground">{transcript}</p>
                  </Card>
                )}
              </div>

              <div className="mt-6 p-4 bg-accent/10 rounded-lg border border-accent/20">
                <p className="text-sm text-muted-foreground">
                  <strong>Demo Mode:</strong> In production, this would integrate with Web Speech API or services like
                  Deepgram, AssemblyAI, or Whisper for real-time transcription.
                </p>
              </div>
            </Card>
          </TabsContent>

          {/* Mind Map Tab */}
          <TabsContent value="mindmap" className="space-y-6">
            <Card className="p-6">
              <h2 className="text-2xl font-bold mb-4">Mind Map Designer</h2>

              <div className="relative w-full h-[600px] bg-muted/30 rounded-lg overflow-hidden touch-none">
                <svg className="w-full h-full">
                  {/* Demo mind map */}
                  <g>
                    {/* Central node */}
                    <circle cx="400" cy="300" r="60" fill="hsl(var(--accent))" opacity="0.2" />
                    <circle cx="400" cy="300" r="50" fill="hsl(var(--accent))" />
                    <text
                      x="400"
                      y="305"
                      textAnchor="middle"
                      fill="hsl(var(--accent-foreground))"
                      className="text-sm font-semibold"
                    >
                      SaaS Project
                    </text>

                    {/* Branch 1: Authentication */}
                    <line x1="400" y1="300" x2="250" y2="200" stroke="hsl(var(--border))" strokeWidth="2" />
                    <circle cx="250" cy="200" r="40" fill="hsl(var(--primary))" />
                    <text x="250" y="205" textAnchor="middle" fill="hsl(var(--primary-foreground))" className="text-xs">
                      Auth
                    </text>

                    {/* Branch 2: Database */}
                    <line x1="400" y1="300" x2="550" y2="200" stroke="hsl(var(--border))" strokeWidth="2" />
                    <circle cx="550" cy="200" r="40" fill="hsl(var(--primary))" />
                    <text x="550" y="205" textAnchor="middle" fill="hsl(var(--primary-foreground))" className="text-xs">
                      Database
                    </text>

                    {/* Branch 3: UI/UX */}
                    <line x1="400" y1="300" x2="250" y2="400" stroke="hsl(var(--border))" strokeWidth="2" />
                    <circle cx="250" cy="400" r="40" fill="hsl(var(--primary))" />
                    <text x="250" y="405" textAnchor="middle" fill="hsl(var(--primary-foreground))" className="text-xs">
                      UI/UX
                    </text>

                    {/* Branch 4: API */}
                    <line x1="400" y1="300" x2="550" y2="400" stroke="hsl(var(--border))" strokeWidth="2" />
                    <circle cx="550" cy="400" r="40" fill="hsl(var(--primary))" />
                    <text x="550" y="405" textAnchor="middle" fill="hsl(var(--primary-foreground))" className="text-xs">
                      API
                    </text>
                  </g>
                </svg>
              </div>

              <div className="mt-6 flex gap-4 flex-wrap">
                <Button variant="outline">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Node
                </Button>
                <Button variant="outline">
                  <GitBranch className="w-4 h-4 mr-2" />
                  Add Branch
                </Button>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>

              <div className="mt-6 p-4 bg-accent/10 rounded-lg border border-accent/20">
                <p className="text-sm text-muted-foreground">
                  <strong>Demo Mode:</strong> In production, this would use React Flow or D3.js for full drag-and-drop
                  mind mapping with zoom, pan, and export capabilities.
                </p>
              </div>
            </Card>
          </TabsContent>

          {/* Workflow Tab */}
          <TabsContent value="workflow" className="space-y-6">
            <Card className="p-6">
              <h2 className="text-2xl font-bold mb-4">Workflow Designer</h2>

              <div className="relative w-full h-[600px] bg-muted/30 rounded-lg overflow-hidden">
                <svg className="w-full h-full">
                  {/* Demo workflow */}
                  <defs>
                    <marker id="arrowhead" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                      <polygon points="0 0, 10 3, 0 6" fill="hsl(var(--border))" />
                    </marker>
                  </defs>

                  {/* Step 1 */}
                  <rect
                    x="50"
                    y="100"
                    width="150"
                    height="80"
                    rx="8"
                    fill="hsl(var(--card))"
                    stroke="hsl(var(--border))"
                    strokeWidth="2"
                  />
                  <text
                    x="125"
                    y="135"
                    textAnchor="middle"
                    fill="hsl(var(--foreground))"
                    className="text-sm font-semibold"
                  >
                    Gather Requirements
                  </text>
                  <text x="125" y="155" textAnchor="middle" fill="hsl(var(--muted-foreground))" className="text-xs">
                    Discovery Phase
                  </text>

                  {/* Arrow 1-2 */}
                  <line
                    x1="200"
                    y1="140"
                    x2="250"
                    y2="140"
                    stroke="hsl(var(--border))"
                    strokeWidth="2"
                    markerEnd="url(#arrowhead)"
                  />

                  {/* Step 2 */}
                  <rect
                    x="250"
                    y="100"
                    width="150"
                    height="80"
                    rx="8"
                    fill="hsl(var(--card))"
                    stroke="hsl(var(--border))"
                    strokeWidth="2"
                  />
                  <text
                    x="325"
                    y="135"
                    textAnchor="middle"
                    fill="hsl(var(--foreground))"
                    className="text-sm font-semibold"
                  >
                    Design System
                  </text>
                  <text x="325" y="155" textAnchor="middle" fill="hsl(var(--muted-foreground))" className="text-xs">
                    UI/UX Phase
                  </text>

                  {/* Arrow 2-3 */}
                  <line
                    x1="400"
                    y1="140"
                    x2="450"
                    y2="140"
                    stroke="hsl(var(--border))"
                    strokeWidth="2"
                    markerEnd="url(#arrowhead)"
                  />

                  {/* Step 3 */}
                  <rect
                    x="450"
                    y="100"
                    width="150"
                    height="80"
                    rx="8"
                    fill="hsl(var(--card))"
                    stroke="hsl(var(--border))"
                    strokeWidth="2"
                  />
                  <text
                    x="525"
                    y="135"
                    textAnchor="middle"
                    fill="hsl(var(--foreground))"
                    className="text-sm font-semibold"
                  >
                    Development
                  </text>
                  <text x="525" y="155" textAnchor="middle" fill="hsl(var(--muted-foreground))" className="text-xs">
                    Build Phase
                  </text>

                  {/* Arrow 3-4 */}
                  <line
                    x1="525"
                    y1="180"
                    x2="525"
                    y2="250"
                    stroke="hsl(var(--border))"
                    strokeWidth="2"
                    markerEnd="url(#arrowhead)"
                  />

                  {/* Step 4 */}
                  <rect
                    x="450"
                    y="250"
                    width="150"
                    height="80"
                    rx="8"
                    fill="hsl(var(--card))"
                    stroke="hsl(var(--border))"
                    strokeWidth="2"
                  />
                  <text
                    x="525"
                    y="285"
                    textAnchor="middle"
                    fill="hsl(var(--foreground))"
                    className="text-sm font-semibold"
                  >
                    Testing & QA
                  </text>
                  <text x="525" y="305" textAnchor="middle" fill="hsl(var(--muted-foreground))" className="text-xs">
                    Quality Phase
                  </text>

                  {/* Arrow 4-5 */}
                  <line
                    x1="450"
                    y1="290"
                    x2="400"
                    y2="290"
                    stroke="hsl(var(--border))"
                    strokeWidth="2"
                    markerEnd="url(#arrowhead)"
                  />

                  {/* Step 5 */}
                  <rect
                    x="250"
                    y="250"
                    width="150"
                    height="80"
                    rx="8"
                    fill="hsl(var(--accent))"
                    stroke="hsl(var(--border))"
                    strokeWidth="2"
                  />
                  <text
                    x="325"
                    y="285"
                    textAnchor="middle"
                    fill="hsl(var(--accent-foreground))"
                    className="text-sm font-semibold"
                  >
                    Launch
                  </text>
                  <text
                    x="325"
                    y="305"
                    textAnchor="middle"
                    fill="hsl(var(--accent-foreground))"
                    className="text-xs opacity-80"
                  >
                    Deployment
                  </text>
                </svg>
              </div>

              <div className="mt-6 flex gap-4 flex-wrap">
                <Button variant="outline">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Step
                </Button>
                <Button variant="outline">
                  <GitBranch className="w-4 h-4 mr-2" />
                  Add Branch
                </Button>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export Workflow
                </Button>
              </div>

              <div className="mt-6 p-4 bg-accent/10 rounded-lg border border-accent/20">
                <p className="text-sm text-muted-foreground">
                  <strong>Demo Mode:</strong> In production, this would use React Flow for interactive workflow design
                  with conditional logic, loops, and automation triggers.
                </p>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
